# Text-to-SQL Agent — Healthcare Claims Data Analyst

A self-improving, context-aware Text-to-SQL agent that converts natural language questions into SQL queries against a healthcare claims database. Powered by GPT-4o, with a Streamlit UI, OpenTelemetry+Phoenix tracing, and a compounding engineering learner module.

## Quick Start

```bash
# 1. Create virtual environment
/opt/anaconda3/bin/python3 -m venv .venv
source .venv/bin/activate

# 2. Install dependencies
pip install -e ".[dev]"

# 3. Set up environment
cp .env.example .env
# Edit .env and add your OPENAI_API_KEY

# 4. Seed the database
python scripts/seed_database.py

# 5. Run the app
streamlit run app.py

# 6. Open in browser (default: http://localhost:8501)
```

## Architecture

```
User Question → Context Engine → SQL Generator → SQL Validator → Execute → NL Responder → Chart
                     ↑                                  ↓
              [Schema + Dictionary          [Self-Correction Loop]
               + Golden Queries                  (max 3 attempts)
               + Conv. Memory]
```

### Core Components

| Module | Purpose |
|--------|---------|
| `context_engine.py` | Assembles 4-layer context (schema, dictionary, golden queries, memory) |
| `sql_generator.py` | NL → SQL via GPT-4o with thinking traces |
| `sql_validator.py` | Safety checks + syntax validation + test execution |
| `orchestrator.py` | Full pipeline with self-correction loop |
| `nl_responder.py` | SQL results → natural language answer |
| `chart_recommender.py` | Auto-picks optimal chart type |
| `otel_setup.py` | OpenTelemetry + Phoenix distributed tracing |

### Learner Module

| Module | Purpose |
|--------|---------|
| `interaction_logger.py` | Logs all queries, results, feedback to SQLite |
| `self_improver.py` | Analyzes failures, proposes dictionary updates, finds golden query candidates |
| `learner_log.md` | Auto-updated lessons from agent interactions |

## Database

6-table healthcare claims model with ~34K total rows:

| Table | Rows | Description |
|-------|------|-------------|
| `members` | 1,000 | Patient demographics |
| `providers` | 200 | Doctor/facility info |
| `diagnoses` | 500 | ICD-10 codes |
| `procedures` | 300 | CPT codes |
| `claims` | 10,000 | Claim headers |
| `claim_lines` | 22,000 | Line-level detail |

## Testing

```bash
# All tests
python -m pytest tests/ -v

# Unit tests only (fast, no API key needed)
python -m pytest tests/unit/ -v

# Integration tests (mocked LLM)
python -m pytest tests/integration/ -v

# Golden query evaluation
python -m pytest tests/integration/test_golden_queries.py -v
```

## Documentation

- [Schema Documentation](data/schema.md) — Full ER diagram + table definitions
- [Data Dictionary](data/data_dictionary.md) — Business definitions + calculated metrics
- [Golden Queries](data/golden_queries.md) — 15 curated evaluation queries
- [Lessons & Skills](lessons_and_skills.md) — Extracted from OpenAI, Compounding Engineering, and community resources
