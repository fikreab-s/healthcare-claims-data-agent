# Healthcare Claims Database — Schema Documentation

## Entity-Relationship Diagram

```mermaid
erDiagram
    MEMBERS ||--o{ CLAIMS : "has"
    PROVIDERS ||--o{ CLAIMS : "submits"
    CLAIMS ||--|{ CLAIM_LINES : "contains"
    DIAGNOSES ||--o{ CLAIM_LINES : "coded_as"
    PROCEDURES ||--o{ CLAIM_LINES : "coded_as"

    MEMBERS {
        text member_id PK
        text first_name
        text last_name
        text date_of_birth
        text gender
        text state
        text zip_code
        text plan_type
        text enrollment_date
        int is_active
    }

    PROVIDERS {
        text provider_id PK
        text npi UK
        text first_name
        text last_name
        text specialty
        text facility_name
        text state
        text network_status
    }

    DIAGNOSES {
        text diagnosis_code PK
        text description
        text category
    }

    PROCEDURES {
        text procedure_code PK
        text description
        text category
        real base_cost
    }

    CLAIMS {
        text claim_id PK
        text member_id FK
        text provider_id FK
        text claim_date
        text admission_date
        text discharge_date
        text place_of_service
        real total_billed_amount
        real total_allowed_amount
        real total_paid_amount
        real member_responsibility
        text claim_status
        text submission_date
        text processed_date
    }

    CLAIM_LINES {
        text claim_line_id PK
        text claim_id FK
        int line_number
        text procedure_code FK
        text diagnosis_code FK
        int quantity
        real billed_amount
        real allowed_amount
        real paid_amount
        real copay
        real coinsurance
        real deductible
        text service_date
    }
```

## Table Details

### `members` — Patient Demographics
| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| member_id | TEXT | PK | Unique patient identifier |
| first_name | TEXT | NOT NULL | Patient first name |
| last_name | TEXT | NOT NULL | Patient last name |
| date_of_birth | TEXT | NOT NULL | Date of birth (ISO 8601) |
| gender | TEXT | CHECK(M/F) | Biological sex |
| state | TEXT | NOT NULL | State of residence (2-letter) |
| zip_code | TEXT | NOT NULL | ZIP code |
| plan_type | TEXT | NOT NULL | Insurance plan type: HMO, PPO, EPO, POS, HDHP |
| enrollment_date | TEXT | NOT NULL | Date member enrolled in plan |
| is_active | INTEGER | DEFAULT 1 | 1 = active, 0 = disenrolled |

### `providers` — Doctor / Facility Information
| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| provider_id | TEXT | PK | Unique provider identifier |
| npi | TEXT | UNIQUE | National Provider Identifier (10-digit) |
| first_name | TEXT | NOT NULL | Provider first name |
| last_name | TEXT | NOT NULL | Provider last name |
| specialty | TEXT | NOT NULL | Medical specialty |
| facility_name | TEXT | NULLABLE | Associated facility (NULL for individual practitioners) |
| state | TEXT | NOT NULL | State where provider practices |
| network_status | TEXT | CHECK | In-Network or Out-of-Network |

### `diagnoses` — ICD-10 Diagnosis Codes
| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| diagnosis_code | TEXT | PK | ICD-10-CM code |
| description | TEXT | NOT NULL | Human-readable diagnosis description |
| category | TEXT | NOT NULL | Disease category (Circulatory, Respiratory, etc.) |

### `procedures` — CPT Procedure Codes
| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| procedure_code | TEXT | PK | CPT code |
| description | TEXT | NOT NULL | Procedure description |
| category | TEXT | NOT NULL | Procedure category (E&M, Lab, Surgery, etc.) |
| base_cost | REAL | NOT NULL | Standard cost for the procedure |

### `claims` — Claim Header
| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| claim_id | TEXT | PK | Unique claim identifier |
| member_id | TEXT | FK → members | Patient who received services |
| provider_id | TEXT | FK → providers | Provider who rendered services |
| claim_date | TEXT | NOT NULL | Date of service |
| admission_date | TEXT | NULLABLE | Inpatient admission date (NULL for outpatient) |
| discharge_date | TEXT | NULLABLE | Inpatient discharge date (NULL for outpatient) |
| place_of_service | TEXT | NOT NULL | Where service was rendered |
| total_billed_amount | REAL | NOT NULL | Total charges submitted by provider |
| total_allowed_amount | REAL | NOT NULL | Total amount allowed by insurance plan |
| total_paid_amount | REAL | NOT NULL | Amount insurance paid |
| member_responsibility | REAL | NOT NULL | Total member out-of-pocket |
| claim_status | TEXT | CHECK | Paid, Denied, Pending, Adjusted |
| submission_date | TEXT | NOT NULL | Date claim was submitted |
| processed_date | TEXT | NULLABLE | Date claim was adjudicated (NULL if Pending) |

### `claim_lines` — Claim Line Detail
| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| claim_line_id | TEXT | PK | Unique line identifier |
| claim_id | TEXT | FK → claims | Parent claim |
| line_number | INTEGER | NOT NULL | Line number within the claim |
| procedure_code | TEXT | FK → procedures | CPT code for service rendered |
| diagnosis_code | TEXT | FK → diagnoses | ICD-10 code for the diagnosis |
| quantity | INTEGER | DEFAULT 1 | Number of units |
| billed_amount | REAL | NOT NULL | Provider's charge for this line |
| allowed_amount | REAL | NOT NULL | Insurance-allowed amount for this line |
| paid_amount | REAL | NOT NULL | Amount insurance paid for this line |
| copay | REAL | DEFAULT 0 | Member copay |
| coinsurance | REAL | DEFAULT 0 | Member coinsurance |
| deductible | REAL | DEFAULT 0 | Amount applied to deductible |
| service_date | TEXT | NOT NULL | Date this specific service was rendered |

## Foreign Key Relationships
| From Table | Column | → To Table | Column |
|------------|--------|------------|--------|
| claims | member_id | members | member_id |
| claims | provider_id | providers | provider_id |
| claim_lines | claim_id | claims | claim_id |
| claim_lines | procedure_code | procedures | procedure_code |
| claim_lines | diagnosis_code | diagnoses | diagnosis_code |
