# Golden Queries — Evaluation Set

> Curated question → SQL → expected-behavior triples for evaluating the Text-to-SQL agent.
> Results are compared by **data output** (not SQL string matching) to handle syntactic variation.

---

## GQ-001: Top 5 Providers by Total Billed Amount

**Question**: What are the top 5 providers by total billed amount?

```sql
SELECT p.provider_id, p.first_name || ' ' || p.last_name AS provider_name,
       p.specialty, SUM(c.total_billed_amount) AS total_billed
FROM claims c
JOIN providers p ON c.provider_id = p.provider_id
GROUP BY p.provider_id, provider_name, p.specialty
ORDER BY total_billed DESC
LIMIT 5;
```

**Expected**: 5 rows, each with provider_id, provider_name, specialty, total_billed. Values should be positive. Ordered descending by total_billed.

---

## GQ-002: Claim Count by Status

**Question**: How many claims are in each status?

```sql
SELECT claim_status, COUNT(*) AS claim_count
FROM claims
GROUP BY claim_status
ORDER BY claim_count DESC;
```

**Expected**: 4 rows (Paid, Denied, Pending, Adjusted). Paid should be the largest.

---

## GQ-003: Average Cost Per Claim by Place of Service

**Question**: What is the average paid amount per claim by place of service?

```sql
SELECT place_of_service, 
       ROUND(AVG(total_paid_amount), 2) AS avg_paid,
       COUNT(*) AS num_claims
FROM claims
WHERE claim_status = 'Paid'
GROUP BY place_of_service
ORDER BY avg_paid DESC;
```

**Expected**: 5 rows (Office, ER, Inpatient, Outpatient, Telehealth). Inpatient should have the highest average.

---

## GQ-004: Monthly Claim Trend

**Question**: Show me the monthly trend of total claims and total paid amounts for the last 12 months.

```sql
SELECT SUBSTR(claim_date, 1, 7) AS month,
       COUNT(*) AS claim_count,
       ROUND(SUM(total_paid_amount), 2) AS total_paid
FROM claims
WHERE claim_date >= DATE('now', '-12 months')
GROUP BY month
ORDER BY month;
```

**Expected**: Up to 12 rows, chronologically ordered. Should show reasonable variation month-to-month.

---

## GQ-005: Denial Rate by Specialty

**Question**: Which provider specialties have the highest denial rates?

```sql
SELECT p.specialty,
       COUNT(*) AS total_claims,
       SUM(CASE WHEN c.claim_status = 'Denied' THEN 1 ELSE 0 END) AS denied_claims,
       ROUND(100.0 * SUM(CASE WHEN c.claim_status = 'Denied' THEN 1 ELSE 0 END) / COUNT(*), 1) AS denial_rate_pct
FROM claims c
JOIN providers p ON c.provider_id = p.provider_id
GROUP BY p.specialty
HAVING COUNT(*) >= 10
ORDER BY denial_rate_pct DESC;
```

**Expected**: Multiple rows. denial_rate_pct should be between 0-100. Should roughly average ~10%.

---

## GQ-006: Top 10 Diagnoses by Frequency

**Question**: What are the 10 most common diagnoses?

```sql
SELECT d.diagnosis_code, d.description, d.category,
       COUNT(*) AS occurrence_count
FROM claim_lines cl
JOIN diagnoses d ON cl.diagnosis_code = d.diagnosis_code
GROUP BY d.diagnosis_code, d.description, d.category
ORDER BY occurrence_count DESC
LIMIT 10;
```

**Expected**: 10 rows. Each should have a valid ICD-10 code and positive count.

---

## GQ-007: Member Out-of-Pocket by Plan Type

**Question**: What is the average member out-of-pocket cost by plan type?

```sql
SELECT m.plan_type,
       COUNT(DISTINCT m.member_id) AS member_count,
       ROUND(AVG(c.member_responsibility), 2) AS avg_oop
FROM claims c
JOIN members m ON c.member_id = m.member_id
WHERE c.claim_status = 'Paid'
GROUP BY m.plan_type
ORDER BY avg_oop DESC;
```

**Expected**: 5 rows (HMO, PPO, EPO, POS, HDHP). HDHP should tend to have higher OOP.

---

## GQ-008: In-Network vs Out-of-Network Cost Comparison

**Question**: Compare the average billed and paid amounts for in-network vs out-of-network providers.

```sql
SELECT p.network_status,
       COUNT(*) AS claim_count,
       ROUND(AVG(c.total_billed_amount), 2) AS avg_billed,
       ROUND(AVG(c.total_paid_amount), 2) AS avg_paid,
       ROUND(AVG(c.total_billed_amount - c.total_paid_amount), 2) AS avg_discount
FROM claims c
JOIN providers p ON c.provider_id = p.provider_id
WHERE c.claim_status = 'Paid'
GROUP BY p.network_status;
```

**Expected**: 2 rows. In-Network should have more claims and lower avg_billed relative to avg_paid.

---

## GQ-009: ER Utilization by State

**Question**: Which states have the highest ER visit rates?

```sql
SELECT m.state,
       COUNT(*) AS total_claims,
       SUM(CASE WHEN c.place_of_service = 'Emergency Room' THEN 1 ELSE 0 END) AS er_claims,
       ROUND(100.0 * SUM(CASE WHEN c.place_of_service = 'Emergency Room' THEN 1 ELSE 0 END) / COUNT(*), 1) AS er_rate_pct
FROM claims c
JOIN members m ON c.member_id = m.member_id
GROUP BY m.state
HAVING COUNT(*) >= 50
ORDER BY er_rate_pct DESC
LIMIT 10;
```

**Expected**: Up to 10 rows. er_rate_pct should be between 5-30% typically.

---

## GQ-010: Average Processing Time by Claim Status

**Question**: What is the average days to process a claim, broken down by status?

```sql
SELECT claim_status,
       COUNT(*) AS claim_count,
       ROUND(AVG(JULIANDAY(processed_date) - JULIANDAY(submission_date)), 1) AS avg_processing_days
FROM claims
WHERE processed_date IS NOT NULL
GROUP BY claim_status
ORDER BY avg_processing_days DESC;
```

**Expected**: 3 rows (Paid, Denied, Adjusted — Pending has NULL processed_date). avg_processing_days should be 5-60.

---

## GQ-011: Total Paid by Procedure Category

**Question**: Break down total insurance payments by procedure category.

```sql
SELECT pr.category,
       COUNT(*) AS line_count,
       ROUND(SUM(cl.paid_amount), 2) AS total_paid,
       ROUND(AVG(cl.paid_amount), 2) AS avg_paid_per_line
FROM claim_lines cl
JOIN procedures pr ON cl.procedure_code = pr.procedure_code
GROUP BY pr.category
ORDER BY total_paid DESC;
```

**Expected**: Multiple rows. Surgery should have highest total or avg.

---

## GQ-012: Patients with Diabetes

**Question**: How many unique patients have a diabetes diagnosis, and what is their average total cost?

```sql
SELECT COUNT(DISTINCT c.member_id) AS diabetes_patients,
       ROUND(SUM(c.total_paid_amount) / COUNT(DISTINCT c.member_id), 2) AS avg_cost_per_patient
FROM claims c
JOIN claim_lines cl ON c.claim_id = cl.claim_id
JOIN diagnoses d ON cl.diagnosis_code = d.diagnosis_code
WHERE d.description LIKE '%diabetes%'
  AND c.claim_status = 'Paid';
```

**Expected**: 1 row. diabetes_patients should be > 0. avg_cost_per_patient should be positive.

---

## GQ-013: Claims Per Member Distribution

**Question**: Show the distribution of how many claims each member has.

```sql
SELECT claims_per_member, COUNT(*) AS member_count
FROM (
    SELECT member_id, COUNT(*) AS claims_per_member
    FROM claims
    GROUP BY member_id
)
GROUP BY claims_per_member
ORDER BY claims_per_member;
```

**Expected**: Multiple rows showing a distribution. Most members should have 5-15 claims.

---

## GQ-014: High-Cost Claims (> $5000)

**Question**: How many claims exceed $5,000 in paid amount, and what provider specialties are involved?

```sql
SELECT p.specialty,
       COUNT(*) AS high_cost_claims,
       ROUND(AVG(c.total_paid_amount), 2) AS avg_paid,
       ROUND(MAX(c.total_paid_amount), 2) AS max_paid
FROM claims c
JOIN providers p ON c.provider_id = p.provider_id
WHERE c.total_paid_amount > 5000
  AND c.claim_status = 'Paid'
GROUP BY p.specialty
ORDER BY high_cost_claims DESC;
```

**Expected**: Several rows. Surgery should be prominent.

---

## GQ-015: Telehealth Utilization Trend

**Question**: Show the quarterly trend of telehealth visits.

```sql
SELECT SUBSTR(claim_date, 1, 4) || '-Q' || 
       CASE 
           WHEN CAST(SUBSTR(claim_date, 6, 2) AS INTEGER) <= 3 THEN '1'
           WHEN CAST(SUBSTR(claim_date, 6, 2) AS INTEGER) <= 6 THEN '2'
           WHEN CAST(SUBSTR(claim_date, 6, 2) AS INTEGER) <= 9 THEN '3'
           ELSE '4'
       END AS quarter,
       COUNT(*) AS telehealth_visits,
       ROUND(SUM(total_paid_amount), 2) AS total_paid
FROM claims
WHERE place_of_service = 'Telehealth'
GROUP BY quarter
ORDER BY quarter;
```

**Expected**: Multiple quarterly rows, ordered chronologically.
