# Healthcare Claims Data Dictionary

> Business definitions, dimension hierarchies, and calculated metrics for the healthcare claims database.

---

## Dimensions

### Member Dimensions
| Dimension | Source Column | Description | Example Values |
|-----------|-------------|-------------|----------------|
| **Age Group** | `members.date_of_birth` | Calculated: `(current_date - date_of_birth) / 365`. Bucketed: 18-25, 26-35, 36-45, 46-55, 56-65, 65+ | "36-45" |
| **Gender** | `members.gender` | Biological sex: M = Male, F = Female | "M", "F" |
| **State** | `members.state` | US state of residence (2-letter code) | "CA", "NY" |
| **Plan Type** | `members.plan_type` | Insurance plan classification | HMO, PPO, EPO, POS, HDHP |
| **Enrollment Status** | `members.is_active` | 1 = currently enrolled, 0 = disenrolled | 1, 0 |
| **Enrollment Tenure** | `members.enrollment_date` | Months since enrollment: `ROUND((JULIANDAY('now') - JULIANDAY(enrollment_date)) / 30)` | 12, 36 |

### Provider Dimensions
| Dimension | Source Column | Description | Example Values |
|-----------|-------------|-------------|----------------|
| **Specialty** | `providers.specialty` | Medical specialty of the provider | "Cardiology", "Family Medicine" |
| **Network Status** | `providers.network_status` | Whether provider participates in the plan's network | "In-Network", "Out-of-Network" |
| **Facility** | `providers.facility_name` | Associated medical facility (NULL = solo practice) | "Acme Medical Center" |
| **Provider State** | `providers.state` | State where the provider practices | "TX", "FL" |

### Diagnosis Dimensions
| Dimension | Source Column | Description | Example Values |
|-----------|-------------|-------------|----------------|
| **Diagnosis Code** | `diagnoses.diagnosis_code` | ICD-10-CM code (international standard) | "E11.9", "I10" |
| **Diagnosis Description** | `diagnoses.description` | Human-readable diagnosis name | "Type 2 diabetes mellitus" |
| **Diagnosis Category** | `diagnoses.category` | High-level disease system | Circulatory, Respiratory, Mental |

### Procedure Dimensions
| Dimension | Source Column | Description | Example Values |
|-----------|-------------|-------------|----------------|
| **Procedure Code** | `procedures.procedure_code` | CPT code (AMA standard) | "99213", "85025" |
| **Procedure Description** | `procedures.description` | Human-readable procedure name | "Office visit, established patient" |
| **Procedure Category** | `procedures.category` | Service line grouping | E&M, Lab, Surgery, Radiology |
| **Base Cost** | `procedures.base_cost` | Standard unit cost before adjustments | $95.00, $1200.00 |

### Claim Dimensions
| Dimension | Source Column | Description | Example Values |
|-----------|-------------|-------------|----------------|
| **Claim Status** | `claims.claim_status` | Processing outcome | Paid, Denied, Pending, Adjusted |
| **Place of Service** | `claims.place_of_service` | Where service was rendered | Office, ER, Inpatient Hospital, Telehealth |
| **Service Year** | `claims.claim_date` | `SUBSTR(claim_date, 1, 4)` | "2023", "2024" |
| **Service Month** | `claims.claim_date` | `SUBSTR(claim_date, 1, 7)` | "2024-01" |
| **Processing Lag** | Calculated | `JULIANDAY(processed_date) - JULIANDAY(submission_date)` in days | 15, 45 |

---

## Calculated Metrics

### Financial Metrics
| Metric | Formula | Description |
|--------|---------|-------------|
| **Total Billed** | `SUM(total_billed_amount)` or `SUM(billed_amount)` | Gross charges submitted by providers |
| **Total Allowed** | `SUM(total_allowed_amount)` or `SUM(allowed_amount)` | Amount contractually allowed by the insurance plan |
| **Total Paid** | `SUM(total_paid_amount)` or `SUM(paid_amount)` | Amount actually paid by insurance |
| **Member Out-of-Pocket** | `SUM(member_responsibility)` or `SUM(copay + coinsurance + deductible)` | Total cost to the patient |
| **Network Discount** | `1 - (allowed_amount / billed_amount)` | Percentage discount from billing to allowed |
| **Payment Rate** | `paid_amount / allowed_amount` | What % of allowed amount insurance actually pays |
| **Average Cost Per Claim** | `SUM(total_paid_amount) / COUNT(claim_id)` | Mean insurance payment per claim |
| **PMPM (Per Member Per Month)** | `SUM(total_paid_amount) / (COUNT(DISTINCT member_id) * months)` | Cost normalized by membership and time |

### Utilization Metrics
| Metric | Formula | Description |
|--------|---------|-------------|
| **Claim Count** | `COUNT(claim_id)` | Number of claims filed |
| **Claims Per Member** | `COUNT(claim_id) / COUNT(DISTINCT member_id)` | Average utilization per member |
| **Unique Patients** | `COUNT(DISTINCT member_id)` | Number of distinct patients |
| **Unique Providers** | `COUNT(DISTINCT provider_id)` | Number of distinct providers |
| **Lines Per Claim** | `COUNT(claim_line_id) / COUNT(DISTINCT claim_id)` | Average services per visit |
| **ER Visit Rate** | `COUNT(CASE WHEN place_of_service='Emergency Room' THEN 1 END) / COUNT(*)` | Proportion of ER claims |
| **Inpatient Rate** | `COUNT(CASE WHEN place_of_service='Inpatient Hospital' THEN 1 END) / COUNT(*)` | Proportion of inpatient claims |
| **Average Length of Stay** | `AVG(JULIANDAY(discharge_date) - JULIANDAY(admission_date))` | Mean inpatient days (inpatient only) |

### Quality / Status Metrics
| Metric | Formula | Description |
|--------|---------|-------------|
| **Denial Rate** | `COUNT(CASE WHEN claim_status='Denied' THEN 1 END) / COUNT(*)` | % of claims denied |
| **Pending Rate** | `COUNT(CASE WHEN claim_status='Pending' THEN 1 END) / COUNT(*)` | % of claims still processing |
| **Clean Claim Rate** | `COUNT(CASE WHEN claim_status='Paid' THEN 1 END) / COUNT(*)` | % of claims paid without adjustment |
| **Average Processing Time** | `AVG(JULIANDAY(processed_date) - JULIANDAY(submission_date))` | Days from submission to adjudication |

---

## Common Business Definitions

| Term | Definition |
|------|-----------|
| **Billed Amount** | The charge the provider submits to insurance. This is the "retail price." |
| **Allowed Amount** | The negotiated rate between the provider and insurance. Always ≤ billed. `allowed = billed × (1 - network_discount)` |
| **Paid Amount** | What insurance actually pays the provider. `paid = allowed - copay - deductible - coinsurance` |
| **Copay** | A fixed dollar amount the member pays per service (e.g., $30 for office visit). |
| **Coinsurance** | A percentage of the allowed amount the member pays (e.g., 20%). |
| **Deductible** | The amount a member must pay out-of-pocket before insurance begins paying. |
| **Member Responsibility** | Total out-of-pocket cost: `copay + coinsurance + deductible` |
| **In-Network** | Provider has a negotiated contract with the insurance plan → lower costs for members. |
| **Out-of-Network** | Provider has no contract → higher costs, potential balance billing. |
| **Place of Service** | Physical location where care was delivered (Office, ER, Inpatient, Telehealth). |
| **ICD-10** | International Classification of Diseases, 10th revision. Standard for diagnosis coding. |
| **CPT** | Current Procedural Terminology. Standard for procedure/service coding. |
| **NPI** | National Provider Identifier. Unique 10-digit ID for healthcare providers. |
| **PMPM** | Per Member Per Month. Common normalization for comparing costs across populations. |

---

## Dimension Hierarchies

```
Diagnosis Hierarchy:
  category → diagnosis_code → description
  Example: Circulatory → I10 → Essential hypertension

Procedure Hierarchy:
  category → procedure_code → description
  Example: Lab → 85025 → Complete blood count (CBC)

Geography Hierarchy:
  state → zip_code
  Example: CA → 90210

Time Hierarchy:
  year → month → date
  Example: 2024 → 2024-03 → 2024-03-15

Provider Hierarchy:
  specialty → provider_id → facility_name (optional)
  Example: Cardiology → PRV001 → Heart Health Center
```
