"""
Golden Query Evaluation Harness.

Runs all golden queries against the database and validates
that they execute successfully and return expected results.
"""

import re
from pathlib import Path

import pytest

from src.config import GOLDEN_QUERIES_PATH
from src.db.connection import execute_query


def _parse_golden_queries() -> list[dict]:
    """Parse golden_queries.md into test cases."""
    if not GOLDEN_QUERIES_PATH.exists():
        return []

    content = GOLDEN_QUERIES_PATH.read_text()
    blocks = re.split(r"(?=## GQ-)", content)
    queries = []

    for block in blocks:
        if not block.strip().startswith("## GQ-"):
            continue

        # Extract ID
        id_match = re.search(r"## (GQ-\d+)", block)
        # Extract question
        q_match = re.search(r"\*\*Question\*\*:\s*(.+)", block)
        # Extract SQL
        sql_match = re.search(r"```sql\n(.+?)```", block, re.DOTALL)
        # Extract expected behavior
        exp_match = re.search(r"\*\*Expected\*\*:\s*(.+?)(?:\n---|\n##|\Z)", block, re.DOTALL)

        if id_match and q_match and sql_match:
            queries.append({
                "id": id_match.group(1),
                "question": q_match.group(1).strip(),
                "sql": sql_match.group(1).strip(),
                "expected": exp_match.group(1).strip() if exp_match else "",
            })

    return queries


GOLDEN_QUERIES = _parse_golden_queries()


@pytest.mark.parametrize(
    "golden_query",
    GOLDEN_QUERIES,
    ids=[q["id"] for q in GOLDEN_QUERIES],
)
def test_golden_query_executes(golden_query, test_db_path):
    """Each golden query should execute without errors."""
    results = execute_query(golden_query["sql"], db_path=test_db_path)
    assert isinstance(results, list), f"Expected list, got {type(results)}"


@pytest.mark.parametrize(
    "golden_query",
    GOLDEN_QUERIES,
    ids=[q["id"] for q in GOLDEN_QUERIES],
)
def test_golden_query_returns_data(golden_query, test_db_path):
    """Each golden query should return at least one row."""
    results = execute_query(golden_query["sql"], db_path=test_db_path)
    assert len(results) > 0, f"Query {golden_query['id']} returned empty results"


@pytest.mark.parametrize(
    "golden_query",
    [q for q in GOLDEN_QUERIES if "LIMIT" in q["sql"].upper()],
    ids=[q["id"] for q in GOLDEN_QUERIES if "LIMIT" in q["sql"].upper()],
)
def test_golden_query_respects_limit(golden_query, test_db_path):
    """Queries with LIMIT should not exceed the limit."""
    # Extract LIMIT value
    limit_match = re.search(r"LIMIT\s+(\d+)", golden_query["sql"], re.IGNORECASE)
    if limit_match:
        limit = int(limit_match.group(1))
        results = execute_query(golden_query["sql"], db_path=test_db_path)
        assert len(results) <= limit
