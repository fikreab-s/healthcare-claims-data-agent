"""
Integration tests — End-to-end query pipeline.

These tests exercise the full pipeline from question to results,
but use mocked LLM calls to avoid needing an API key.
"""

import json
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from src.agent.orchestrator import TextToSQLAgent


class TestPipeline:
    """End-to-end pipeline tests with mocked LLM."""

    def _mock_generation(self, sql: str):
        """Create mock for sql_generator call_llm."""
        return json.dumps({
            "thinking": "Test thinking",
            "sql": sql,
            "explanation": "Test explanation",
        })

    def _mock_nl(self, answer: str):
        """Create mock for nl_responder call_llm."""
        return json.dumps({
            "answer": answer,
            "key_insights": ["Test insight"],
            "suggested_followups": ["Follow-up question?"],
        })

    @patch("src.agent.sql_generator.call_llm")
    @patch("src.agent.nl_responder.call_llm")
    def test_simple_count_query(self, mock_nl_call_llm, mock_gen_call_llm, test_db_path):
        """End-to-end test: count query."""
        mock_gen_call_llm.return_value = self._mock_generation(
            "SELECT COUNT(*) as total_members FROM members"
        )
        mock_nl_call_llm.return_value = self._mock_nl(
            "There are 1,000 members in the database."
        )

        agent = TextToSQLAgent(db_path=test_db_path)
        resp = agent.query("How many members are there?")

        assert resp.success is True
        assert resp.row_count >= 1
        assert "total_members" in resp.column_names
        assert resp.results[0]["total_members"] == 1000

    @patch("src.agent.sql_generator.call_llm")
    @patch("src.agent.nl_responder.call_llm")
    def test_aggregation_query(self, mock_nl_call_llm, mock_gen_call_llm, test_db_path):
        """End-to-end test: group-by aggregation."""
        sql = """
        SELECT claim_status, COUNT(*) as cnt 
        FROM claims 
        GROUP BY claim_status 
        ORDER BY cnt DESC
        """
        mock_gen_call_llm.return_value = self._mock_generation(sql)
        mock_nl_call_llm.return_value = self._mock_nl("Claims by status")

        agent = TextToSQLAgent(db_path=test_db_path)
        resp = agent.query("How many claims per status?")

        assert resp.success is True
        assert resp.row_count == 4  # Paid, Denied, Pending, Adjusted
        statuses = {r["claim_status"] for r in resp.results}
        assert "Paid" in statuses

    @patch("src.agent.sql_generator.call_llm")
    @patch("src.agent.nl_responder.call_llm")
    def test_join_query(self, mock_nl_call_llm, mock_gen_call_llm, test_db_path):
        """End-to-end test: multi-table join."""
        sql = """
        SELECT p.specialty, COUNT(*) as claim_count
        FROM claims c
        JOIN providers p ON c.provider_id = p.provider_id
        GROUP BY p.specialty
        ORDER BY claim_count DESC
        LIMIT 5
        """
        mock_gen_call_llm.return_value = self._mock_generation(sql)
        mock_nl_call_llm.return_value = self._mock_nl("Top specialties")

        agent = TextToSQLAgent(db_path=test_db_path)
        resp = agent.query("Top 5 specialties by claim count")

        assert resp.success is True
        assert resp.row_count <= 5
        assert "specialty" in resp.column_names

    @patch("src.agent.sql_generator.call_llm")
    def test_invalid_sql_fails(self, mock_gen_call_llm, test_db_path):
        """Should handle invalid SQL gracefully."""
        mock_gen_call_llm.return_value = self._mock_generation(
            "SELECT * FROM nonexistent_table"
        )
        
        agent = TextToSQLAgent(db_path=test_db_path)
        resp = agent.query("Show data from a fake table")

        assert resp.success is False
        assert len(resp.errors) > 0
