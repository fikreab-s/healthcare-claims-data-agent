"""
Shared test fixtures for the Text-to-SQL Agent.
"""

import sqlite3
import tempfile
from pathlib import Path

import pytest

from src.db.generate_data import generate_database


@pytest.fixture(scope="session")
def test_db_path() -> Path:
    """Create a temporary test database with healthcare data."""
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = Path(tmpdir) / "test_healthcare.db"
        generate_database(db_path)
        yield db_path


@pytest.fixture
def db_connection(test_db_path: Path):
    """Provide a SQLite connection to the test database."""
    conn = sqlite3.connect(str(test_db_path))
    conn.row_factory = sqlite3.Row
    yield conn
    conn.close()


@pytest.fixture
def sample_results() -> list[dict]:
    """Sample query results for testing NL responder and chart recommender."""
    return [
        {"specialty": "Cardiology", "total_claims": 500, "total_paid": 125000.50},
        {"specialty": "Orthopedics", "total_claims": 450, "total_paid": 180000.75},
        {"specialty": "Family Medicine", "total_claims": 1200, "total_paid": 95000.25},
        {"specialty": "Neurology", "total_claims": 300, "total_paid": 110000.00},
        {"specialty": "Dermatology", "total_claims": 350, "total_paid": 45000.30},
    ]


@pytest.fixture
def sample_time_series() -> list[dict]:
    """Sample time series results for chart testing."""
    return [
        {"month": "2024-01", "claim_count": 850, "total_paid": 425000.00},
        {"month": "2024-02", "claim_count": 920, "total_paid": 460000.00},
        {"month": "2024-03", "claim_count": 880, "total_paid": 440000.00},
        {"month": "2024-04", "claim_count": 950, "total_paid": 475000.00},
    ]
