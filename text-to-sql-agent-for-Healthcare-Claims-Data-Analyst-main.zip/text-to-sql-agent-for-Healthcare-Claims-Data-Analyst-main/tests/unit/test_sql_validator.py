"""
Unit tests for the SQL Validator.
"""

from pathlib import Path

import pytest

from src.agent.sql_validator import (
    _check_safety,
    _validate_syntax,
    validate_sql,
    execute_validated_sql,
)


class TestSafetyChecks:
    """Tests for SQL safety enforcement."""

    def test_select_is_safe(self):
        assert _check_safety("SELECT * FROM members") is None

    def test_with_cte_is_safe(self):
        assert _check_safety("WITH cte AS (SELECT 1) SELECT * FROM cte") is None

    def test_insert_is_unsafe(self):
        result = _check_safety("INSERT INTO members VALUES (1)")
        assert result is not None
        assert "INSERT" in result

    def test_delete_is_unsafe(self):
        result = _check_safety("DELETE FROM members")
        assert result is not None

    def test_drop_is_unsafe(self):
        result = _check_safety("DROP TABLE members")
        assert result is not None

    def test_update_is_unsafe(self):
        result = _check_safety("UPDATE members SET first_name = 'x'")
        assert result is not None

    def test_multiple_statements_blocked(self):
        result = _check_safety("SELECT 1; DROP TABLE members")
        assert result is not None
        # May catch DROP keyword or multi-statement — both are correct blocks
        assert "Multiple" in result or "Unsafe" in result

    def test_empty_query(self):
        result = _check_safety("")
        assert result is not None


class TestSyntaxValidation:
    """Tests for SQL syntax checking."""

    def test_valid_query(self, test_db_path: Path):
        result = _validate_syntax("SELECT COUNT(*) FROM members", test_db_path)
        assert result is None

    def test_invalid_table(self, test_db_path: Path):
        result = _validate_syntax("SELECT * FROM nonexistent_table", test_db_path)
        assert result is not None

    def test_invalid_column(self, test_db_path: Path):
        result = _validate_syntax("SELECT nonexistent_col FROM members", test_db_path)
        assert result is not None

    def test_valid_join(self, test_db_path: Path):
        sql = """
        SELECT m.first_name, c.claim_date
        FROM members m
        JOIN claims c ON m.member_id = c.member_id
        LIMIT 5
        """
        result = _validate_syntax(sql, test_db_path)
        assert result is None


class TestFullValidation:
    """Tests for the complete validation pipeline."""

    def test_valid_query_passes(self, test_db_path: Path):
        result = validate_sql("SELECT COUNT(*) as n FROM members", test_db_path)
        assert result.is_valid is True
        assert result.row_count >= 1

    def test_unsafe_query_blocked(self, test_db_path: Path):
        result = validate_sql("DELETE FROM members", test_db_path)
        assert result.is_valid is False
        assert "Unsafe" in result.error_message or "DELETE" in result.error_message

    def test_empty_query_fails(self, test_db_path: Path):
        result = validate_sql("", test_db_path)
        assert result.is_valid is False

    def test_complex_query(self, test_db_path: Path):
        sql = """
        SELECT p.specialty, COUNT(*) as claim_count,
               ROUND(AVG(c.total_paid_amount), 2) as avg_paid
        FROM claims c
        JOIN providers p ON c.provider_id = p.provider_id
        GROUP BY p.specialty
        ORDER BY claim_count DESC
        LIMIT 10
        """
        result = validate_sql(sql, test_db_path)
        assert result.is_valid is True
        assert len(result.column_names) == 3

    def test_execute_validated_sql(self, test_db_path: Path):
        results = execute_validated_sql(
            "SELECT claim_status, COUNT(*) as n FROM claims GROUP BY claim_status",
            test_db_path,
        )
        assert len(results) > 0
        assert "claim_status" in results[0]
        assert "n" in results[0]
