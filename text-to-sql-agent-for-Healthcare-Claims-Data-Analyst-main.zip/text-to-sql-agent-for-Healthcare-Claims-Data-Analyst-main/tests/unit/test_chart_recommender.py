"""
Unit tests for the Chart Recommender.
"""

import pytest

from src.agent.chart_recommender import recommend_chart, ChartRecommendation


class TestChartRecommender:
    """Tests for auto chart type detection."""

    def test_empty_results(self):
        """Empty results should return table-only."""
        rec = recommend_chart([])
        assert rec.chart_type == "table"
        assert rec.is_chartable is False

    def test_single_row(self):
        """Single row results should return table-only."""
        rec = recommend_chart([{"count": 42}])
        assert rec.chart_type == "table"
        assert rec.is_chartable is False

    def test_bar_chart_categorical(self, sample_results):
        """Categorical + numeric should recommend bar chart."""
        rec = recommend_chart(sample_results, "Compare specialties by total paid")
        assert rec.chart_type == "bar"
        assert rec.x_column == "specialty"
        assert rec.y_column in ["total_claims", "total_paid"]

    def test_line_chart_time_series(self, sample_time_series):
        """Time-like x column should recommend line chart."""
        rec = recommend_chart(sample_time_series, "Monthly trend")
        assert rec.chart_type == "line"
        assert rec.x_column == "month"

    def test_pie_chart_distribution(self):
        """Small categorical with distribution keyword → pie."""
        data = [
            {"status": "Paid", "count": 7000},
            {"status": "Denied", "count": 1000},
            {"status": "Pending", "count": 1200},
            {"status": "Adjusted", "count": 800},
        ]
        rec = recommend_chart(data, "Claim breakdown by status")
        assert rec.chart_type == "pie"

    def test_hbar_many_categories(self):
        """Many categories should recommend horizontal bar."""
        data = [{"state": f"S{i}", "count": i * 100} for i in range(15)]
        rec = recommend_chart(data, "Claims by state")
        assert rec.chart_type == "hbar"

    def test_title_from_question(self, sample_results):
        """Title should be derived from the question."""
        rec = recommend_chart(sample_results, "Top specialties by total paid")
        assert "Top specialties" in rec.title
