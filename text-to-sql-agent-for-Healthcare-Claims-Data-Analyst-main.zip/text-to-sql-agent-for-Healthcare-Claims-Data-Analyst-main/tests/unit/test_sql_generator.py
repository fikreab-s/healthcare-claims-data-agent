"""
Unit tests for the SQL Generator (mocked LLM).
"""

import json
from unittest.mock import MagicMock, patch

import pytest

from src.agent.sql_generator import generate_sql, generate_corrected_sql, SQLGenerationResult


class TestSQLGenerator:
    """Tests for SQL generation with mocked OpenAI responses."""

    @patch("src.agent.sql_generator.call_llm")
    def test_basic_generation(self, mock_call_llm):
        """Should generate SQL from a question."""
        expected = {
            "thinking": "Need to count members table",
            "sql": "SELECT COUNT(*) FROM members",
            "explanation": "Counts all members",
        }
        mock_call_llm.return_value = json.dumps(expected)

        result = generate_sql("How many members?", "schema context here", api_key="test")
        assert result.sql == "SELECT COUNT(*) FROM members"
        assert result.thinking == "Need to count members table"
        assert result.explanation == "Counts all members"
        assert result.prompt_tokens == 0
        assert result.completion_tokens == 0
        assert len(result.errors) == 0

    @patch("src.agent.sql_generator.call_llm")
    def test_empty_response_handling(self, mock_call_llm):
        """Should handle empty LLM response gracefully."""
        mock_call_llm.return_value = "{}"

        result = generate_sql("test", "context", api_key="test")
        assert result.sql == ""

    @patch("src.agent.sql_generator.call_llm")
    def test_api_error_handling(self, mock_call_llm):
        """Should handle API errors gracefully."""
        mock_call_llm.side_effect = Exception("API error")

        result = generate_sql("test", "context", api_key="test")
        assert len(result.errors) > 0
        assert "API error" in result.errors[0]

    @patch("src.agent.sql_generator.call_llm")
    def test_correction_generation(self, mock_call_llm):
        """Should generate corrected SQL."""
        expected = {
            "thinking": "Fixed the column name",
            "sql": "SELECT member_id FROM members",
            "explanation": "Corrected query",
        }
        mock_call_llm.return_value = json.dumps(expected)

        result = generate_corrected_sql(
            "Show member IDs",
            "schema context",
            "SELECT id FROM members",
            "no such column: id",
            api_key="test",
        )
        assert result.sql == "SELECT member_id FROM members"
        assert "Fixed" in result.thinking
