"""
Unit tests for the Context Engine.
"""

from pathlib import Path

import pytest

from src.agent.context_engine import ContextEngine


class TestContextEngine:
    """Tests for multi-layer context assembly."""

    def test_schema_context_not_empty(self, test_db_path: Path):
        """Schema context should contain table definitions."""
        engine = ContextEngine(db_path=test_db_path)
        schema = engine.get_schema_context()
        assert len(schema) > 0
        assert "members" in schema
        assert "claims" in schema
        assert "claim_lines" in schema
        assert "providers" in schema
        assert "diagnoses" in schema
        assert "procedures" in schema

    def test_schema_contains_columns(self, test_db_path: Path):
        """Schema should describe column details."""
        engine = ContextEngine(db_path=test_db_path)
        schema = engine.get_schema_context()
        assert "member_id" in schema
        assert "claim_date" in schema
        assert "total_billed_amount" in schema

    def test_schema_caching(self, test_db_path: Path):
        """Second call should return cached result."""
        engine = ContextEngine(db_path=test_db_path)
        s1 = engine.get_schema_context()
        s2 = engine.get_schema_context()
        assert s1 is s2  # Same object (cached)

    def test_golden_queries_parsing(self, test_db_path: Path):
        """Should parse golden queries from markdown."""
        engine = ContextEngine(db_path=test_db_path)
        examples = engine.get_golden_query_examples(n=3)
        # If golden_queries.md exists, should have examples
        assert isinstance(examples, str)

    def test_conversation_history(self, test_db_path: Path):
        """Conversation history should be maintained."""
        engine = ContextEngine(db_path=test_db_path)
        engine.add_to_history("user", "What are the top providers?")
        engine.add_to_history("assistant", "Here are the top 5 providers...")
        context = engine.get_conversation_context()
        assert "top providers" in context
        assert "top 5" in context

    def test_clear_history(self, test_db_path: Path):
        """Clearing history should reset the memory."""
        engine = ContextEngine(db_path=test_db_path)
        engine.add_to_history("user", "test question")
        engine.clear_history()
        context = engine.get_conversation_context()
        assert context == ""

    def test_full_context_assembly(self, test_db_path: Path):
        """Full context should include all layers."""
        engine = ContextEngine(db_path=test_db_path)
        full = engine.build_full_context()
        assert "Database Schema" in full
        assert "members" in full
        assert len(full) > 100  # Should be substantial
