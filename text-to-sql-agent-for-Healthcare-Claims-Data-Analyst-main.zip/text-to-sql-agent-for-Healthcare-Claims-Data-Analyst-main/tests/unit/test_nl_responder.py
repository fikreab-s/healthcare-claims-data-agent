"""
Unit tests for the NL Responder (mocked LLM).
"""

import json
from unittest.mock import MagicMock, patch

import pytest

from src.agent.nl_responder import generate_nl_response


class TestNLResponder:
    """Tests for natural language response generation."""

    @patch("src.agent.nl_responder.call_llm")
    def test_basic_response(self, mock_call_llm, sample_results):
        """Should generate a meaningful NL response."""
        expected = {
            "answer": "The top specialty is Orthopedics with $180,000 in payments.",
            "key_insights": ["Orthopedics leads in total paid"],
            "suggested_followups": ["What are the denial rates by specialty?"],
        }
        mock_call_llm.return_value = json.dumps(expected)

        result = generate_nl_response(
            "Top specialties by payment",
            "SELECT specialty FROM ...",
            sample_results,
            api_key="test",
        )
        assert "Orthopedics" in result["answer"]
        assert len(result["key_insights"]) > 0
        assert len(result["suggested_followups"]) > 0

    @patch("src.agent.nl_responder.call_llm")
    def test_empty_results_handling(self, mock_call_llm):
        """Should handle empty results gracefully."""
        expected = {
            "answer": "The query returned no results.",
            "key_insights": [],
            "suggested_followups": [],
        }
        mock_call_llm.return_value = json.dumps(expected)

        result = generate_nl_response("test", "SELECT 1", [], api_key="test")
        assert "no results" in result["answer"]

    @patch("src.agent.nl_responder.call_llm")
    def test_api_failure_fallback(self, mock_call_llm, sample_results):
        """Should provide fallback response on API failure."""
        mock_call_llm.side_effect = Exception("API down")

        result = generate_nl_response("test", "SELECT 1", sample_results, api_key="test")
        assert "5 row" in result["answer"]  # Fallback mentions row count
