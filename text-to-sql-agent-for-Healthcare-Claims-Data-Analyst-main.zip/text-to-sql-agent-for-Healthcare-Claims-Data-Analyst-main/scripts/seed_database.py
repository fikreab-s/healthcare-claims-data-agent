#!/usr/bin/env python3
"""One-shot database seeder. Run this to create/recreate the healthcare claims DB."""

import sys
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.config import DB_PATH
from src.db.generate_data import generate_database

if __name__ == "__main__":
    print(f"Generating healthcare claims database at: {DB_PATH}")
    counts = generate_database(DB_PATH)
    print("\n✅ Database created successfully!\n")
    print("Table row counts:")
    for table, count in counts.items():
        print(f"  {table:15s} → {count:>7,} rows")
    print(f"\nDatabase size: {DB_PATH.stat().st_size / 1024 / 1024:.1f} MB")
