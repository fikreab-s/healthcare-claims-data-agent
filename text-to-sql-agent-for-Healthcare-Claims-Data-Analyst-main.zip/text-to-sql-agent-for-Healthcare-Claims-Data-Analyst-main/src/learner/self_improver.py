"""
Self-Improver — Analyzes interactions and updates the knowledge base.

Periodically:
  - Identifies common failure patterns
  - Proposes data dictionary updates
  - Auto-generates golden query candidates from successful interactions
  - Updates learner_log.md with discovered patterns
"""

from __future__ import annotations

import json
import logging
import sqlite3
from datetime import datetime
from pathlib import Path

from src.config import DB_PATH, LEARNER_LOG_PATH
from src.learner.interaction_logger import InteractionLogger

logger = logging.getLogger(__name__)


class SelfImprover:
    """Analyzes interaction history and proposes improvements."""

    def __init__(self, db_path: Path = DB_PATH):
        self.db_path = db_path
        self.interaction_logger = InteractionLogger(db_path)
        self.log_path = LEARNER_LOG_PATH

    def analyze_failures(self) -> list[dict]:
        """
        Analyze recent failures to find systematic patterns.
        
        Returns a list of discovered patterns, each with:
          - pattern: Description of the issue
          - frequency: How often it occurs
          - suggestion: How to fix it
        """
        conn = sqlite3.connect(str(self.db_path))
        conn.row_factory = sqlite3.Row

        # Get recent failures
        failures = conn.execute("""
            SELECT question, generated_sql, error_message, thinking_trace
            FROM interactions
            WHERE is_valid = 0
            ORDER BY id DESC
            LIMIT 50
        """).fetchall()
        conn.close()

        patterns = []
        error_types: dict[str, int] = {}

        for f in failures:
            error = f["error_message"] or ""
            # Categorize errors
            if "no such column" in error.lower():
                key = "Column name mismatch"
            elif "no such table" in error.lower():
                key = "Table name mismatch"
            elif "syntax error" in error.lower():
                key = "SQL syntax error"
            elif "ambiguous column" in error.lower():
                key = "Ambiguous column reference"
            elif "unsafe" in error.lower():
                key = "Safety check failure"
            else:
                key = "Other error"

            error_types[key] = error_types.get(key, 0) + 1

        for pattern_name, count in sorted(error_types.items(), key=lambda x: -x[1]):
            suggestions = {
                "Column name mismatch": "Update schema context with correct column names and aliases",
                "Table name mismatch": "Verify table names in schema match the prompt context",
                "SQL syntax error": "Add more SQLite-specific examples to golden queries",
                "Ambiguous column reference": "Always use table aliases in multi-table queries",
                "Safety check failure": "Review safety check rules for false positives",
                "Other error": "Review error logs for new failure modes",
            }
            patterns.append({
                "pattern": pattern_name,
                "frequency": count,
                "suggestion": suggestions.get(pattern_name, "Investigate further"),
            })

        return patterns

    def find_golden_query_candidates(self) -> list[dict]:
        """
        Find successful interactions that could become golden queries.
        
        Criteria:
          - is_valid = True
          - user_feedback = 'positive' OR no negative feedback
          - No self-corrections needed
          - Diverse question types
        """
        conn = sqlite3.connect(str(self.db_path))
        conn.row_factory = sqlite3.Row

        candidates = conn.execute("""
            SELECT question, generated_sql, nl_answer, row_count
            FROM interactions
            WHERE is_valid = 1
              AND correction_attempts = 0
              AND (user_feedback IS NULL OR user_feedback = 'positive')
            ORDER BY id DESC
            LIMIT 20
        """).fetchall()
        conn.close()

        return [
            {
                "question": c["question"],
                "sql": c["generated_sql"],
                "answer_preview": (c["nl_answer"] or "")[:200],
                "row_count": c["row_count"],
            }
            for c in candidates
        ]

    def update_learner_log(self) -> str:
        """
        Update the learner_log.md with current analysis.
        Returns the updated content.
        """
        stats = self.interaction_logger.get_failure_stats()
        patterns = self.analyze_failures()
        candidates = self.find_golden_query_candidates()

        sections = [
            "# Learner Log — Auto-Updated Lessons from Agent Interactions\n",
            f"> Last updated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n",
            "---\n",
            "## Interaction Statistics\n",
            f"| Metric | Value |",
            f"|--------|-------|",
            f"| Total Queries | {stats['total_queries']} |",
            f"| Failures | {stats['failures']} ({stats['failure_rate']}%) |",
            f"| Self-Corrections | {stats['self_corrections']} |",
            f"| Negative Feedback | {stats['negative_feedback']} |",
            f"| Avg Success Time | {stats['avg_success_time_ms']:.0f} ms |",
            "",
            "## Discovered Failure Patterns\n",
        ]

        if patterns:
            sections.append("| Pattern | Frequency | Suggestion |")
            sections.append("|---------|-----------|------------|")
            for p in patterns:
                sections.append(
                    f"| {p['pattern']} | {p['frequency']} | {p['suggestion']} |"
                )
        else:
            sections.append("_No failure patterns detected yet._")

        sections.extend([
            "",
            "## Golden Query Candidates\n",
        ])

        if candidates:
            for i, c in enumerate(candidates[:5], 1):
                sections.append(f"### Candidate {i}")
                sections.append(f"**Q**: {c['question']}")
                sections.append(f"```sql\n{c['sql']}\n```")
                sections.append(f"_Returns {c['row_count']} rows_\n")
        else:
            sections.append("_No candidates yet._")

        content = "\n".join(sections)

        # Write to file
        self.log_path.parent.mkdir(parents=True, exist_ok=True)
        self.log_path.write_text(content)

        return content

    def run_improvement_cycle(self) -> dict:
        """
        Run a full improvement cycle:
          1. Analyze failures
          2. Find golden query candidates
          3. Update learner log
        
        Returns summary of findings.
        """
        patterns = self.analyze_failures()
        candidates = self.find_golden_query_candidates()
        self.update_learner_log()

        return {
            "failure_patterns": len(patterns),
            "golden_candidates": len(candidates),
            "log_updated": True,
        }
