"""
Interaction Logger — Records all agent interactions for learning.

Captures queries, generated SQL, results, user feedback,
and trace IDs for cross-referencing with Phoenix.
"""

from __future__ import annotations

import json
import logging
import sqlite3
from datetime import datetime
from pathlib import Path

from src.config import DB_PATH

logger = logging.getLogger(__name__)

INTERACTIONS_DDL = """
CREATE TABLE IF NOT EXISTS interactions (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp       TEXT NOT NULL,
    question        TEXT NOT NULL,
    generated_sql   TEXT,
    is_valid        INTEGER,
    error_message   TEXT,
    row_count       INTEGER,
    nl_answer       TEXT,
    thinking_trace  TEXT,
    correction_attempts INTEGER DEFAULT 0,
    total_time_ms   REAL,
    prompt_tokens   INTEGER,
    completion_tokens INTEGER,
    user_feedback   TEXT,  -- 'positive', 'negative', or NULL
    user_correction TEXT,  -- user-provided correct SQL or feedback text
    trace_id        TEXT,
    model           TEXT
);
"""


class InteractionLogger:
    """Logs agent interactions to a SQLite table and learner_log.md."""

    def __init__(self, db_path: Path = DB_PATH):
        self.db_path = db_path
        self._ensure_table()

    def _ensure_table(self) -> None:
        """Create the interactions table if it doesn't exist."""
        conn = sqlite3.connect(str(self.db_path))
        conn.executescript(INTERACTIONS_DDL)
        conn.close()

    def log_interaction(
        self,
        question: str,
        generated_sql: str = "",
        is_valid: bool = False,
        error_message: str = "",
        row_count: int = 0,
        nl_answer: str = "",
        thinking_trace: str = "",
        correction_attempts: int = 0,
        total_time_ms: float = 0,
        prompt_tokens: int = 0,
        completion_tokens: int = 0,
        model: str = "",
        trace_id: str = "",
    ) -> int:
        """
        Log an agent interaction.
        Returns the interaction ID.
        """
        conn = sqlite3.connect(str(self.db_path))
        cursor = conn.execute(
            """INSERT INTO interactions 
               (timestamp, question, generated_sql, is_valid, error_message,
                row_count, nl_answer, thinking_trace, correction_attempts,
                total_time_ms, prompt_tokens, completion_tokens, model, trace_id)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                datetime.now().isoformat(),
                question,
                generated_sql,
                1 if is_valid else 0,
                error_message,
                row_count,
                nl_answer,
                thinking_trace,
                correction_attempts,
                total_time_ms,
                prompt_tokens,
                completion_tokens,
                model,
                trace_id,
            ),
        )
        conn.commit()
        interaction_id = cursor.lastrowid
        conn.close()
        return interaction_id

    def log_from_response(self, response) -> int:
        """Log from an AgentResponse object."""
        return self.log_interaction(
            question=response.question,
            generated_sql=response.sql,
            is_valid=response.is_valid,
            error_message=response.validation_error,
            row_count=response.row_count,
            nl_answer=response.nl_answer,
            thinking_trace=response.thinking,
            correction_attempts=response.correction_attempts,
            total_time_ms=response.total_time_ms,
            prompt_tokens=response.prompt_tokens,
            completion_tokens=response.completion_tokens,
            model=response.model,
        )

    def record_feedback(
        self, interaction_id: int, feedback: str, correction: str = ""
    ) -> None:
        """Record user feedback for an interaction."""
        conn = sqlite3.connect(str(self.db_path))
        conn.execute(
            "UPDATE interactions SET user_feedback = ?, user_correction = ? WHERE id = ?",
            (feedback, correction, interaction_id),
        )
        conn.commit()
        conn.close()

    def get_recent_interactions(self, limit: int = 20) -> list[dict]:
        """Return recent interactions."""
        conn = sqlite3.connect(str(self.db_path))
        conn.row_factory = sqlite3.Row
        rows = conn.execute(
            "SELECT * FROM interactions ORDER BY id DESC LIMIT ?", (limit,)
        ).fetchall()
        conn.close()
        return [dict(row) for row in rows]

    def get_failure_stats(self) -> dict:
        """Return aggregate failure statistics."""
        conn = sqlite3.connect(str(self.db_path))
        conn.row_factory = sqlite3.Row

        total = conn.execute("SELECT COUNT(*) as n FROM interactions").fetchone()["n"]
        failures = conn.execute(
            "SELECT COUNT(*) as n FROM interactions WHERE is_valid = 0"
        ).fetchone()["n"]
        corrections = conn.execute(
            "SELECT COUNT(*) as n FROM interactions WHERE correction_attempts > 0"
        ).fetchone()["n"]
        negative = conn.execute(
            "SELECT COUNT(*) as n FROM interactions WHERE user_feedback = 'negative'"
        ).fetchone()["n"]

        avg_time = conn.execute(
            "SELECT AVG(total_time_ms) as avg FROM interactions WHERE is_valid = 1"
        ).fetchone()["avg"]

        conn.close()

        return {
            "total_queries": total,
            "failures": failures,
            "failure_rate": round(failures / total * 100, 1) if total > 0 else 0,
            "self_corrections": corrections,
            "negative_feedback": negative,
            "avg_success_time_ms": round(avg_time or 0, 1),
        }
