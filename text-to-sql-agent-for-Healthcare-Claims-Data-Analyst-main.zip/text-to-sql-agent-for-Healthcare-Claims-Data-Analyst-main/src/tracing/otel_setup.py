"""
OpenTelemetry + Phoenix Tracing Setup.

Configures distributed tracing with:
  - OpenTelemetry TracerProvider
  - Phoenix as span exporter (local UI at localhost:6006)
  - OpenAI auto-instrumentation via openinference
  - Custom spans for each agent pipeline step
"""

from __future__ import annotations

import logging
from functools import wraps
from typing import Any, Callable

logger = logging.getLogger(__name__)

# Global state
_tracer = None
_phoenix_session = None
_initialized = False


def init_tracing(launch_phoenix: bool = True) -> Any:
    """
    Initialize OpenTelemetry tracing with Phoenix.
    
    Args:
        launch_phoenix: If True, launch Phoenix UI locally.
    
    Returns:
        The tracer instance.
    """
    global _tracer, _phoenix_session, _initialized

    if _initialized:
        return _tracer

    try:
        from opentelemetry import trace
        from opentelemetry.sdk.trace import TracerProvider
        from opentelemetry.sdk.trace.export import SimpleSpanProcessor

        # Launch Phoenix
        if launch_phoenix:
            try:
                import phoenix as px
                _phoenix_session = px.launch_app()
                logger.info(f"Phoenix UI launched at: {_phoenix_session.url}")
            except Exception as e:
                logger.warning(f"Could not launch Phoenix: {e}")

        # Set up TracerProvider
        provider = TracerProvider()

        # Add Phoenix exporter
        try:
            from phoenix.otel import register
            register(project_name="tts-agent")
        except Exception:
            try:
                from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
                exporter = OTLPSpanExporter(endpoint="http://localhost:6006/v1/traces")
                provider.add_span_processor(SimpleSpanProcessor(exporter))
            except Exception as e:
                logger.warning(f"Could not setup trace exporter: {e}")

        trace.set_tracer_provider(provider)
        _tracer = trace.get_tracer("tts-agent")

        # Auto-instrument OpenAI
        try:
            from openinference.instrumentation.openai import OpenAIInstrumentor
            OpenAIInstrumentor().instrument()
            logger.info("OpenAI auto-instrumentation enabled")
        except Exception as e:
            logger.warning(f"OpenAI instrumentation failed: {e}")

        _initialized = True
        return _tracer

    except ImportError as e:
        logger.warning(f"Tracing dependencies not available: {e}")
        _initialized = True
        return None


def get_tracer():
    """Return the global tracer (initialize if needed)."""
    global _tracer
    if not _initialized:
        init_tracing(launch_phoenix=False)
    return _tracer


def traced(span_name: str | None = None):
    """
    Decorator to wrap a function in an OpenTelemetry span.
    
    Usage:
        @traced("my_operation")
        def my_function(x, y):
            ...
    """
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, **kwargs):
            tracer = get_tracer()
            name = span_name or func.__name__

            if tracer:
                with tracer.start_as_current_span(name) as span:
                    try:
                        result = func(*args, **kwargs)
                        span.set_attribute("status", "success")
                        return result
                    except Exception as e:
                        span.set_attribute("status", "error")
                        span.set_attribute("error.message", str(e))
                        raise
            else:
                return func(*args, **kwargs)

        return wrapper
    return decorator
