"""
Central configuration for the Text-to-SQL Agent.
Loads environment variables and provides typed settings.
"""

import os
from pathlib import Path
from dotenv import load_dotenv

# ── Paths ────────────────────────────────────────────────────────────────
PROJECT_ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = PROJECT_ROOT / "data"
DB_PATH = DATA_DIR / "healthcare_claims.db"
SCHEMA_PATH = DATA_DIR / "schema.md"
DATA_DICT_PATH = DATA_DIR / "data_dictionary.md"
GOLDEN_QUERIES_PATH = DATA_DIR / "golden_queries.md"
LEARNER_LOG_PATH = PROJECT_ROOT / "src" / "learner" / "learner_log.md"

# ── Environment ──────────────────────────────────────────────────────────
load_dotenv(PROJECT_ROOT / ".env")

OPENAI_API_KEY: str = os.getenv("OPENAI_API_KEY", "")
OPENAI_MODEL: str = os.getenv("OPENAI_MODEL", "gpt-4o")

GOOGLE_API_KEY: str = os.getenv("GOOGLE_API_KEY", "")
GEMINI_MODEL: str = os.getenv("GEMINI_MODEL", "gemini-flash-latest")
LLM_PROVIDER: str = os.getenv("LLM_PROVIDER", "openai").lower()

PHOENIX_PORT: int = int(os.getenv("PHOENIX_PORT", "6006"))

# ── Agent Settings ───────────────────────────────────────────────────────
MAX_SELF_CORRECTION_ATTEMPTS: int = 3
SQL_RESULT_ROW_LIMIT: int = 500
CONTEXT_MAX_GOLDEN_QUERIES: int = 5
