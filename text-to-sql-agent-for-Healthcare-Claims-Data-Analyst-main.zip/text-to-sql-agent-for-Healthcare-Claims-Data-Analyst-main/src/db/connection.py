"""
SQLite connection manager with context-manager support.
"""

import sqlite3
from contextlib import contextmanager
from pathlib import Path
from typing import Generator

from src.config import DB_PATH


def get_connection(db_path: Path = DB_PATH) -> sqlite3.Connection:
    """Return a new SQLite connection with row-factory enabled."""
    conn = sqlite3.connect(str(db_path))
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


@contextmanager
def get_cursor(db_path: Path = DB_PATH) -> Generator[sqlite3.Cursor, None, None]:
    """Context manager yielding a cursor; auto-commits on success."""
    conn = get_connection(db_path)
    try:
        cursor = conn.cursor()
        yield cursor
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def execute_query(sql: str, params: tuple = (), db_path: Path = DB_PATH) -> list[dict]:
    """Execute a read query and return results as list of dicts."""
    conn = get_connection(db_path)
    try:
        cursor = conn.execute(sql, params)
        columns = [desc[0] for desc in cursor.description] if cursor.description else []
        rows = cursor.fetchall()
        return [dict(zip(columns, row)) for row in rows]
    finally:
        conn.close()


def execute_write(sql: str, params: tuple = (), db_path: Path = DB_PATH) -> int:
    """Execute a write query and return rows affected."""
    conn = get_connection(db_path)
    try:
        cursor = conn.execute(sql, params)
        conn.commit()
        return cursor.rowcount
    finally:
        conn.close()


def get_table_names(db_path: Path = DB_PATH) -> list[str]:
    """Return all user table names in the database."""
    rows = execute_query(
        "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'",
        db_path=db_path,
    )
    return [r["name"] for r in rows]


def get_table_schema(table_name: str, db_path: Path = DB_PATH) -> list[dict]:
    """Return column info for a table via PRAGMA."""
    return execute_query(f"PRAGMA table_info({table_name})", db_path=db_path)
