"""
Healthcare Claims Data Generator.

Generates realistic healthcare claims data across 6 related tables
and loads it into a SQLite database.

Tables:
  - members        (1,000 rows)  — patient demographics
  - providers       (200 rows)   — doctor / facility info
  - diagnoses       (500 rows)   — ICD-10 codes + descriptions
  - procedures      (300 rows)   — CPT codes + descriptions
  - claims         (10,000 rows) — one row per claim
  - claim_lines    (25,000 rows) — line-level detail
"""

import random
import sqlite3
import uuid
from datetime import date, timedelta
from pathlib import Path

from faker import Faker

fake = Faker()
Faker.seed(42)
random.seed(42)

# ── Reference Data ───────────────────────────────────────────────────────

PLAN_TYPES = ["HMO", "PPO", "EPO", "POS", "HDHP"]
GENDERS = ["M", "F"]
STATES = [
    "CA", "TX", "FL", "NY", "PA", "IL", "OH", "GA", "NC", "MI",
    "NJ", "VA", "WA", "AZ", "MA", "TN", "IN", "MO", "MD", "WI",
]

SPECIALTIES = [
    "Family Medicine", "Internal Medicine", "Cardiology", "Orthopedics",
    "Dermatology", "Pediatrics", "Neurology", "Oncology", "Psychiatry",
    "Emergency Medicine", "Radiology", "Anesthesiology", "Ophthalmology",
    "Urology", "Gastroenterology", "Pulmonology", "Endocrinology",
    "Rheumatology", "Nephrology", "General Surgery",
]

NETWORK_STATUSES = ["In-Network", "Out-of-Network"]
CLAIM_STATUSES = ["Paid", "Denied", "Pending", "Adjusted"]
PLACE_OF_SERVICE = ["Office", "Outpatient Hospital", "Inpatient Hospital", "Emergency Room", "Telehealth"]

# ── ICD-10 Diagnosis Codes (sample) ─────────────────────────────────────

ICD10_CODES = [
    ("E11.9", "Type 2 diabetes mellitus without complications", "Endocrine"),
    ("I10", "Essential (primary) hypertension", "Circulatory"),
    ("J06.9", "Acute upper respiratory infection, unspecified", "Respiratory"),
    ("M54.5", "Low back pain", "Musculoskeletal"),
    ("K21.0", "Gastro-esophageal reflux disease with esophagitis", "Digestive"),
    ("F32.9", "Major depressive disorder, single episode, unspecified", "Mental"),
    ("J45.909", "Unspecified asthma, uncomplicated", "Respiratory"),
    ("E78.5", "Dyslipidemia, unspecified", "Endocrine"),
    ("N39.0", "Urinary tract infection, site not specified", "Genitourinary"),
    ("G43.909", "Migraine, unspecified, not intractable", "Nervous"),
    ("I25.10", "Atherosclerotic heart disease of native coronary artery", "Circulatory"),
    ("E03.9", "Hypothyroidism, unspecified", "Endocrine"),
    ("J20.9", "Acute bronchitis, unspecified", "Respiratory"),
    ("M79.3", "Panniculitis, unspecified", "Musculoskeletal"),
    ("R10.9", "Unspecified abdominal pain", "Digestive"),
    ("L70.0", "Acne vulgaris", "Skin"),
    ("H52.1", "Myopia", "Eye"),
    ("K58.9", "Irritable bowel syndrome without diarrhea", "Digestive"),
    ("G47.00", "Insomnia, unspecified", "Nervous"),
    ("M25.50", "Pain in unspecified joint", "Musculoskeletal"),
    ("J02.9", "Acute pharyngitis, unspecified", "Respiratory"),
    ("B34.9", "Viral infection, unspecified", "Infectious"),
    ("R51", "Headache", "Nervous"),
    ("L30.9", "Dermatitis, unspecified", "Skin"),
    ("E66.01", "Morbid (severe) obesity due to excess calories", "Endocrine"),
    ("I48.91", "Unspecified atrial fibrillation", "Circulatory"),
    ("N18.3", "Chronic kidney disease, stage 3", "Genitourinary"),
    ("J44.1", "COPD with acute exacerbation", "Respiratory"),
    ("G40.909", "Epilepsy, unspecified, not intractable", "Nervous"),
    ("C50.919", "Malignant neoplasm of unspecified site of breast", "Neoplasm"),
    ("D64.9", "Anemia, unspecified", "Blood"),
    ("M81.0", "Age-related osteoporosis without fracture", "Musculoskeletal"),
    ("E55.9", "Vitamin D deficiency, unspecified", "Endocrine"),
    ("R05", "Cough", "Respiratory"),
    ("F41.1", "Generalized anxiety disorder", "Mental"),
    ("Z23", "Encounter for immunization", "Factors"),
    ("Z00.00", "Encounter for general adult medical exam", "Factors"),
    ("Z12.31", "Encounter for screening mammogram", "Factors"),
    ("Z01.00", "Encounter for examination of eyes", "Factors"),
    ("Z87.39", "Personal history of other diseases of musculoskeletal system", "Factors"),
]

# ── CPT Procedure Codes (sample) ────────────────────────────────────────

CPT_CODES = [
    ("99213", "Office visit, established patient, low complexity", "E&M", 95.00),
    ("99214", "Office visit, established patient, moderate complexity", "E&M", 150.00),
    ("99215", "Office visit, established patient, high complexity", "E&M", 210.00),
    ("99203", "Office visit, new patient, low complexity", "E&M", 130.00),
    ("99204", "Office visit, new patient, moderate complexity", "E&M", 200.00),
    ("99205", "Office visit, new patient, high complexity", "E&M", 280.00),
    ("99281", "Emergency department visit, minor", "Emergency", 150.00),
    ("99283", "Emergency department visit, moderate", "Emergency", 350.00),
    ("99285", "Emergency department visit, high severity", "Emergency", 750.00),
    ("99385", "Preventive visit, new patient, 18-39 years", "Preventive", 175.00),
    ("99395", "Preventive visit, established patient, 18-39 years", "Preventive", 160.00),
    ("99396", "Preventive visit, established patient, 40-64 years", "Preventive", 175.00),
    ("36415", "Collection of venous blood by venipuncture", "Lab", 12.00),
    ("80053", "Comprehensive metabolic panel", "Lab", 35.00),
    ("85025", "Complete blood count (CBC)", "Lab", 20.00),
    ("80061", "Lipid panel", "Lab", 30.00),
    ("81001", "Urinalysis, automated", "Lab", 10.00),
    ("87880", "Strep test, rapid", "Lab", 18.00),
    ("71046", "Chest X-ray, 2 views", "Radiology", 125.00),
    ("73030", "Shoulder X-ray, minimum 2 views", "Radiology", 100.00),
    ("72148", "MRI lumbar spine without contrast", "Radiology", 800.00),
    ("70553", "MRI brain with and without contrast", "Radiology", 1200.00),
    ("93000", "Electrocardiogram (ECG), 12-lead", "Cardiology", 50.00),
    ("93306", "Echocardiography, transthoracic", "Cardiology", 450.00),
    ("93458", "Left heart catheterization", "Cardiology", 3500.00),
    ("43239", "Upper GI endoscopy with biopsy", "Surgery", 900.00),
    ("45380", "Colonoscopy with biopsy", "Surgery", 1200.00),
    ("27447", "Total knee replacement", "Surgery", 25000.00),
    ("27130", "Total hip replacement", "Surgery", 28000.00),
    ("29881", "Knee arthroscopy with meniscectomy", "Surgery", 5000.00),
    ("10060", "Incision and drainage of abscess", "Surgery", 350.00),
    ("11102", "Tangential biopsy of skin", "Surgery", 150.00),
    ("17000", "Destruction of premalignant lesion, first", "Dermatology", 80.00),
    ("17110", "Destruction of benign lesions, up to 14", "Dermatology", 120.00),
    ("90471", "Immunization administration, first vaccine", "Preventive", 25.00),
    ("90715", "Tdap vaccine", "Preventive", 45.00),
    ("90686", "Influenza vaccine, quadrivalent", "Preventive", 30.00),
    ("96372", "Therapeutic injection, subcutaneous or IM", "Injection", 35.00),
    ("20610", "Arthrocentesis, major joint", "Injection", 200.00),
    ("90837", "Psychotherapy, 60 minutes", "Behavioral", 175.00),
    ("90834", "Psychotherapy, 45 minutes", "Behavioral", 130.00),
    ("90832", "Psychotherapy, 30 minutes", "Behavioral", 90.00),
    ("97110", "Therapeutic exercises", "Rehab", 55.00),
    ("97140", "Manual therapy techniques", "Rehab", 60.00),
    ("97530", "Therapeutic activities", "Rehab", 55.00),
    ("99441", "Telephone E&M, 5-10 min", "Telehealth", 45.00),
    ("99442", "Telephone E&M, 11-20 min", "Telehealth", 75.00),
    ("99443", "Telephone E&M, 21-30 min", "Telehealth", 105.00),
]


# ── DDL ──────────────────────────────────────────────────────────────────

DDL = """
CREATE TABLE IF NOT EXISTS members (
    member_id       TEXT PRIMARY KEY,
    first_name      TEXT NOT NULL,
    last_name       TEXT NOT NULL,
    date_of_birth   TEXT NOT NULL,
    gender          TEXT NOT NULL CHECK(gender IN ('M','F')),
    state           TEXT NOT NULL,
    zip_code        TEXT NOT NULL,
    plan_type       TEXT NOT NULL,
    enrollment_date TEXT NOT NULL,
    is_active       INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS providers (
    provider_id     TEXT PRIMARY KEY,
    npi             TEXT NOT NULL UNIQUE,
    first_name      TEXT NOT NULL,
    last_name       TEXT NOT NULL,
    specialty       TEXT NOT NULL,
    facility_name   TEXT,
    state           TEXT NOT NULL,
    network_status  TEXT NOT NULL CHECK(network_status IN ('In-Network','Out-of-Network'))
);

CREATE TABLE IF NOT EXISTS diagnoses (
    diagnosis_code  TEXT PRIMARY KEY,
    description     TEXT NOT NULL,
    category        TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS procedures (
    procedure_code  TEXT PRIMARY KEY,
    description     TEXT NOT NULL,
    category        TEXT NOT NULL,
    base_cost       REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS claims (
    claim_id            TEXT PRIMARY KEY,
    member_id           TEXT NOT NULL REFERENCES members(member_id),
    provider_id         TEXT NOT NULL REFERENCES providers(provider_id),
    claim_date          TEXT NOT NULL,
    admission_date      TEXT,
    discharge_date      TEXT,
    place_of_service    TEXT NOT NULL,
    total_billed_amount REAL NOT NULL,
    total_allowed_amount REAL NOT NULL,
    total_paid_amount   REAL NOT NULL,
    member_responsibility REAL NOT NULL,
    claim_status        TEXT NOT NULL CHECK(claim_status IN ('Paid','Denied','Pending','Adjusted')),
    submission_date     TEXT NOT NULL,
    processed_date      TEXT
);

CREATE TABLE IF NOT EXISTS claim_lines (
    claim_line_id   TEXT PRIMARY KEY,
    claim_id        TEXT NOT NULL REFERENCES claims(claim_id),
    line_number     INTEGER NOT NULL,
    procedure_code  TEXT NOT NULL REFERENCES procedures(procedure_code),
    diagnosis_code  TEXT NOT NULL REFERENCES diagnoses(diagnosis_code),
    quantity        INTEGER NOT NULL DEFAULT 1,
    billed_amount   REAL NOT NULL,
    allowed_amount  REAL NOT NULL,
    paid_amount     REAL NOT NULL,
    copay           REAL NOT NULL DEFAULT 0,
    coinsurance     REAL NOT NULL DEFAULT 0,
    deductible      REAL NOT NULL DEFAULT 0,
    service_date    TEXT NOT NULL
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_claims_member ON claims(member_id);
CREATE INDEX IF NOT EXISTS idx_claims_provider ON claims(provider_id);
CREATE INDEX IF NOT EXISTS idx_claims_date ON claims(claim_date);
CREATE INDEX IF NOT EXISTS idx_claims_status ON claims(claim_status);
CREATE INDEX IF NOT EXISTS idx_claim_lines_claim ON claim_lines(claim_id);
CREATE INDEX IF NOT EXISTS idx_claim_lines_procedure ON claim_lines(procedure_code);
CREATE INDEX IF NOT EXISTS idx_claim_lines_diagnosis ON claim_lines(diagnosis_code);
"""


# ── Generator Functions ──────────────────────────────────────────────────

def _generate_members(n: int = 1000) -> list[tuple]:
    rows = []
    for _ in range(n):
        dob = fake.date_of_birth(minimum_age=18, maximum_age=85)
        enrollment = fake.date_between(start_date="-5y", end_date="-30d")
        rows.append((
            str(uuid.uuid4())[:12],
            fake.first_name(),
            fake.last_name(),
            dob.isoformat(),
            random.choice(GENDERS),
            random.choice(STATES),
            fake.zipcode(),
            random.choice(PLAN_TYPES),
            enrollment.isoformat(),
            random.choices([1, 0], weights=[0.92, 0.08])[0],
        ))
    return rows


def _generate_providers(n: int = 200) -> list[tuple]:
    rows = []
    for _ in range(n):
        rows.append((
            str(uuid.uuid4())[:12],
            fake.numerify("##########"),
            fake.first_name(),
            fake.last_name(),
            random.choice(SPECIALTIES),
            fake.company() + " Medical Center" if random.random() < 0.4 else None,
            random.choice(STATES),
            random.choices(NETWORK_STATUSES, weights=[0.8, 0.2])[0],
        ))
    return rows


def _generate_diagnoses() -> list[tuple]:
    # Use our curated list + generate extras to reach ~500
    rows = [(code, desc, cat) for code, desc, cat in ICD10_CODES]
    categories = ["Circulatory", "Respiratory", "Digestive", "Musculoskeletal",
                   "Endocrine", "Mental", "Nervous", "Skin", "Genitourinary",
                   "Blood", "Neoplasm", "Infectious", "Factors", "Eye"]
    for i in range(len(rows), 500):
        cat = random.choice(categories)
        code = f"Z{random.randint(70, 99)}.{random.randint(0, 9)}{random.randint(0, 9)}"
        rows.append((
            f"{code}{i}",
            f"Synthetic diagnosis {i} ({cat.lower()})",
            cat,
        ))
    return rows


def _generate_procedures() -> list[tuple]:
    rows = [(code, desc, cat, cost) for code, desc, cat, cost in CPT_CODES]
    categories = ["E&M", "Lab", "Radiology", "Surgery", "Preventive", "Injection",
                   "Behavioral", "Rehab", "Telehealth", "Cardiology", "Dermatology"]
    for i in range(len(rows), 300):
        cat = random.choice(categories)
        cost = round(random.uniform(20, 2000), 2)
        rows.append((
            f"X{random.randint(10000, 99999)}{i}",
            f"Synthetic procedure {i} ({cat.lower()})",
            cat,
            cost,
        ))
    return rows


def _generate_claims_and_lines(
    member_ids: list[str],
    provider_ids: list[str],
    diagnosis_codes: list[str],
    procedure_data: list[tuple],  # (code, base_cost)
    n_claims: int = 10_000,
) -> tuple[list[tuple], list[tuple]]:
    claims = []
    lines = []

    for _ in range(n_claims):
        claim_id = str(uuid.uuid4())[:12]
        member_id = random.choice(member_ids)
        provider_id = random.choice(provider_ids)
        claim_date = fake.date_between(start_date="-3y", end_date="today")
        pos = random.choice(PLACE_OF_SERVICE)

        # Determine if inpatient
        is_inpatient = pos == "Inpatient Hospital"
        admission_date = claim_date if is_inpatient else None
        stay_days = random.randint(1, 14) if is_inpatient else 0
        discharge_date = (claim_date + timedelta(days=stay_days)) if is_inpatient else None

        # Generate 1-5 claim lines
        n_lines = random.choices([1, 2, 3, 4, 5], weights=[0.35, 0.30, 0.20, 0.10, 0.05])[0]
        total_billed = 0.0
        total_allowed = 0.0
        total_paid = 0.0
        total_member = 0.0

        for line_num in range(1, n_lines + 1):
            proc_code, base_cost = random.choice(procedure_data)
            diag_code = random.choice(diagnosis_codes)
            quantity = random.choices([1, 2, 3], weights=[0.8, 0.15, 0.05])[0]

            # Pricing logic
            billed = round(base_cost * quantity * random.uniform(0.9, 1.3), 2)
            network_discount = random.uniform(0.55, 0.85)
            allowed = round(billed * network_discount, 2)
            copay = round(random.choice([0, 20, 30, 40, 50, 75]), 2)
            deductible = round(random.choice([0, 0, 0, 50, 100, 200, 500]), 2)
            coinsurance_rate = random.choice([0.0, 0.10, 0.20, 0.30])
            coinsurance = round((allowed - copay - deductible) * coinsurance_rate, 2)
            coinsurance = max(0, coinsurance)
            paid = round(max(0, allowed - copay - deductible - coinsurance), 2)
            member_resp = round(copay + deductible + coinsurance, 2)

            total_billed += billed
            total_allowed += allowed
            total_paid += paid
            total_member += member_resp

            lines.append((
                str(uuid.uuid4())[:12],
                claim_id,
                line_num,
                proc_code,
                diag_code,
                quantity,
                billed,
                allowed,
                paid,
                copay,
                coinsurance,
                deductible,
                claim_date.isoformat(),
            ))

        # Claim status
        status = random.choices(
            CLAIM_STATUSES,
            weights=[0.70, 0.10, 0.12, 0.08],
        )[0]
        if status == "Denied":
            total_paid = 0.0
            total_member = 0.0

        submission_lag = random.randint(0, 30)
        submission_date = claim_date + timedelta(days=submission_lag)
        processing_lag = random.randint(5, 60)
        processed_date = (
            (submission_date + timedelta(days=processing_lag)).isoformat()
            if status != "Pending" else None
        )

        claims.append((
            claim_id,
            member_id,
            provider_id,
            claim_date.isoformat(),
            admission_date.isoformat() if admission_date else None,
            discharge_date.isoformat() if discharge_date else None,
            pos,
            round(total_billed, 2),
            round(total_allowed, 2),
            round(total_paid, 2),
            round(total_member, 2),
            status,
            submission_date.isoformat(),
            processed_date,
        ))

    return claims, lines


# ── Main Entry Point ─────────────────────────────────────────────────────

def generate_database(db_path: Path) -> dict[str, int]:
    """
    Generate the full healthcare claims database.
    Returns a dict of table_name → row_count.
    """
    db_path.parent.mkdir(parents=True, exist_ok=True)

    # Remove existing DB to start fresh
    if db_path.exists():
        db_path.unlink()

    conn = sqlite3.connect(str(db_path))
    cursor = conn.cursor()

    # Create tables
    cursor.executescript(DDL)

    # --- Members ---
    members = _generate_members(1000)
    cursor.executemany(
        "INSERT INTO members VALUES (?,?,?,?,?,?,?,?,?,?)",
        members,
    )
    member_ids = [m[0] for m in members]

    # --- Providers ---
    providers = _generate_providers(200)
    cursor.executemany(
        "INSERT INTO providers VALUES (?,?,?,?,?,?,?,?)",
        providers,
    )
    provider_ids = [p[0] for p in providers]

    # --- Diagnoses ---
    diagnoses = _generate_diagnoses()
    cursor.executemany(
        "INSERT OR IGNORE INTO diagnoses VALUES (?,?,?)",
        diagnoses,
    )
    diagnosis_codes = [d[0] for d in diagnoses]

    # --- Procedures ---
    procedures = _generate_procedures()
    cursor.executemany(
        "INSERT OR IGNORE INTO procedures VALUES (?,?,?,?)",
        procedures,
    )
    procedure_data = [(p[0], p[3]) for p in procedures]

    # --- Claims & Claim Lines ---
    claims, claim_lines = _generate_claims_and_lines(
        member_ids, provider_ids, diagnosis_codes, procedure_data, 10_000,
    )
    cursor.executemany(
        "INSERT INTO claims VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        claims,
    )
    cursor.executemany(
        "INSERT INTO claim_lines VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
        claim_lines,
    )

    conn.commit()

    # Collect counts
    counts = {}
    for table in ["members", "providers", "diagnoses", "procedures", "claims", "claim_lines"]:
        cursor.execute(f"SELECT COUNT(*) FROM {table}")
        counts[table] = cursor.fetchone()[0]

    conn.close()
    return counts


if __name__ == "__main__":
    from src.config import DB_PATH
    print("Generating healthcare claims database...")
    counts = generate_database(DB_PATH)
    print("Done! Table row counts:")
    for table, count in counts.items():
        print(f"  {table}: {count:,}")
