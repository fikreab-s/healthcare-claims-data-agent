"""
Context Engine — Builds rich context for the LLM from multiple layers.

Layers:
  1. Schema Metadata (live PRAGMA introspection)
  2. Data Dictionary (business definitions, calculations)
  3. Golden Queries (few-shot examples)
  4. Conversational Memory (session history)
"""

from __future__ import annotations

import random
import re
from pathlib import Path

from src.config import DATA_DICT_PATH, DB_PATH, GOLDEN_QUERIES_PATH, SCHEMA_PATH, CONTEXT_MAX_GOLDEN_QUERIES
from src.db.connection import get_table_names, get_table_schema


class ContextEngine:
    """Assembles multi-layer context for SQL generation prompts."""

    def __init__(self, db_path: Path = DB_PATH):
        self.db_path = db_path
        self._schema_cache: str | None = None
        self._data_dict_cache: str | None = None
        self._golden_queries_cache: list[dict] | None = None
        self._conversation_history: list[dict] = []

    # ── Layer 1: Schema Metadata ─────────────────────────────────────

    def get_schema_context(self) -> str:
        """Introspect the SQLite DB and return DDL-like schema description."""
        if self._schema_cache:
            return self._schema_cache

        tables = get_table_names(self.db_path)
        parts = ["## Database Schema\n"]
        for table in tables:
            columns = get_table_schema(table, self.db_path)
            parts.append(f"### Table: `{table}`")
            parts.append("| Column | Type | Nullable | PK |")
            parts.append("|--------|------|----------|----|")
            for col in columns:
                nullable = "NO" if col["notnull"] else "YES"
                pk = "✓" if col["pk"] else ""
                parts.append(f"| {col['name']} | {col['type']} | {nullable} | {pk} |")
            parts.append("")

        # Add FK relationships
        parts.append("### Foreign Key Relationships")
        parts.append("- `claims.member_id` → `members.member_id`")
        parts.append("- `claims.provider_id` → `providers.provider_id`")
        parts.append("- `claim_lines.claim_id` → `claims.claim_id`")
        parts.append("- `claim_lines.procedure_code` → `procedures.procedure_code`")
        parts.append("- `claim_lines.diagnosis_code` → `diagnoses.diagnosis_code`")

        self._schema_cache = "\n".join(parts)
        return self._schema_cache

    # ── Layer 2: Data Dictionary ─────────────────────────────────────

    def get_data_dictionary_context(self) -> str:
        """Load the data dictionary markdown."""
        if self._data_dict_cache:
            return self._data_dict_cache

        if DATA_DICT_PATH.exists():
            content = DATA_DICT_PATH.read_text()
            # Extract the key sections (skip the verbose hierarchy)
            self._data_dict_cache = content
        else:
            self._data_dict_cache = "(Data dictionary not available)"

        return self._data_dict_cache

    # ── Layer 3: Golden Queries ──────────────────────────────────────

    def _parse_golden_queries(self) -> list[dict]:
        """Parse golden_queries.md into structured examples."""
        if self._golden_queries_cache is not None:
            return self._golden_queries_cache

        self._golden_queries_cache = []
        if not GOLDEN_QUERIES_PATH.exists():
            return self._golden_queries_cache

        content = GOLDEN_QUERIES_PATH.read_text()
        # Split by ## GQ- markers
        blocks = re.split(r"(?=## GQ-)", content)
        for block in blocks:
            if not block.strip().startswith("## GQ-"):
                continue
            # Extract question
            q_match = re.search(r"\*\*Question\*\*:\s*(.+)", block)
            # Extract SQL
            sql_match = re.search(r"```sql\n(.+?)```", block, re.DOTALL)
            if q_match and sql_match:
                self._golden_queries_cache.append({
                    "question": q_match.group(1).strip(),
                    "sql": sql_match.group(1).strip(),
                })

        return self._golden_queries_cache

    def get_golden_query_examples(self, n: int = CONTEXT_MAX_GOLDEN_QUERIES) -> str:
        """Return a random sample of golden queries as few-shot examples."""
        queries = self._parse_golden_queries()
        if not queries:
            return "(No golden query examples available)"

        sample = random.sample(queries, min(n, len(queries)))
        parts = ["## Example Queries\n"]
        for i, q in enumerate(sample, 1):
            parts.append(f"### Example {i}")
            parts.append(f"**Question**: {q['question']}")
            parts.append(f"```sql\n{q['sql']}\n```\n")

        return "\n".join(parts)

    # ── Layer 4: Conversational Memory ───────────────────────────────

    def add_to_history(self, role: str, content: str) -> None:
        """Add a message to conversation history."""
        self._conversation_history.append({"role": role, "content": content})

    def get_conversation_context(self, max_turns: int = 5) -> str:
        """Return recent conversation history as context."""
        if not self._conversation_history:
            return ""

        recent = self._conversation_history[-(max_turns * 2):]
        parts = ["## Recent Conversation\n"]
        for msg in recent:
            role = "User" if msg["role"] == "user" else "Assistant"
            parts.append(f"**{role}**: {msg['content'][:200]}")

        return "\n".join(parts)

    def clear_history(self) -> None:
        """Reset conversation memory."""
        self._conversation_history = []

    # ── Full Context Assembly ────────────────────────────────────────

    def build_full_context(self) -> str:
        """Assemble all context layers into a single prompt section."""
        sections = [
            self.get_schema_context(),
            "",
            "---",
            "",
            self.get_data_dictionary_context(),
            "",
            "---",
            "",
            self.get_golden_query_examples(),
        ]

        conv = self.get_conversation_context()
        if conv:
            sections.extend(["", "---", "", conv])

        return "\n".join(sections)
