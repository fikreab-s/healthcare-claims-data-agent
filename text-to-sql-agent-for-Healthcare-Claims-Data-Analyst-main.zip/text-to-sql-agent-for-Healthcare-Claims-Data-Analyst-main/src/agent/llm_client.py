"""
LLM Client Abstraction.

Unified interface for OpenAI and Google Gemini models.
"""

from __future__ import annotations

import json
import logging
from typing import Any

from src.config import (
    GEMINI_MODEL,
    GOOGLE_API_KEY,
    LLM_PROVIDER,
    OPENAI_API_KEY,
    OPENAI_MODEL,
)

logger = logging.getLogger(__name__)


def call_llm(
    messages: list[dict[str, str]],
    temperature: float = 0.0,
    json_mode: bool = False,
    model: str | None = None,
) -> str:
    """
    Call the configured LLM provider.
    
    Args:
        messages: List of message dicts (role, content).
                  First message with role 'system' is treated as system prompt.
        temperature: Sampling temperature.
        json_mode: Whether to enforce JSON output.
        model: Optional model override.
        
    Returns:
        The raw text response content.
    """
    provider = LLM_PROVIDER
    
    if provider == "gemini":
        return _call_gemini(messages, temperature, json_mode, model)
    else:
        return _call_openai(messages, temperature, json_mode, model)


def _call_openai(
    messages: list[dict[str, str]],
    temperature: float,
    json_mode: bool,
    model: str | None,
) -> str:
    """Call OpenAI ChatCompletion."""
    from openai import OpenAI
    
    client = OpenAI(api_key=OPENAI_API_KEY)
    model = model or OPENAI_MODEL
    
    response_format = {"type": "json_object"} if json_mode else None
    
    try:
        response = client.chat.completions.create(
            model=model,
            messages=messages,
            temperature=temperature,
            response_format=response_format,
        )
        return response.choices[0].message.content or ""
    except Exception as e:
        logger.error(f"OpenAI call failed: {e}")
        raise


def _call_gemini(
    messages: list[dict[str, str]],
    temperature: float,
    json_mode: bool,
    model: str | None,
) -> str:
    """Call Google Gemini API."""
    import google.generativeai as genai
    
    if not GOOGLE_API_KEY:
        raise ValueError("GOOGLE_API_KEY is not set")
        
    genai.configure(api_key=GOOGLE_API_KEY)
    model_name = model or GEMINI_MODEL
    
    # Extract system prompt if present
    system_prompt = None
    chat_history = []
    
    for msg in messages:
        if msg["role"] == "system":
            system_prompt = msg["content"]
        elif msg["role"] == "user":
            chat_history.append({"role": "user", "parts": [msg["content"]]})
        elif msg["role"] == "assistant":
            chat_history.append({"role": "model", "parts": [msg["content"]]})
            
    generation_config = genai.types.GenerationConfig(
        temperature=temperature,
    )
    
    if json_mode:
        generation_config.response_mime_type = "application/json"
        
    import time
    
    max_retries = 3
    base_delay = 2
    
    for attempt in range(max_retries):
        try:
            model_instance = genai.GenerativeModel(
                model_name=model_name,
                system_instruction=system_prompt
            )
            
            # Reconstruct chat session for each attempt
            if not chat_history:
                return ""
                
            # Separate last message for send_message
            last_message_content = chat_history[-1]["parts"][0]
            history = chat_history[:-1] if len(chat_history) > 1 else []
            
            chat = model_instance.start_chat(history=history)
            
            # Send message with expanded timeout if supported, otherwise robust retries help
            response = chat.send_message(
                last_message_content, 
                generation_config=generation_config,
                request_options={"timeout": 600}
            )
            
            return response.text
            
        except Exception as e:
            if "504" in str(e) or "Deadline" in str(e) or "429" in str(e):
                if attempt < max_retries - 1:
                    delay = base_delay * (2 ** attempt)
                    logger.warning(f"Gemini call failed (attempt {attempt+1}/{max_retries}): {e}. Retrying in {delay}s...")
                    time.sleep(delay)
                    continue
            logger.error(f"Gemini call failed permanently: {e}")
            raise
