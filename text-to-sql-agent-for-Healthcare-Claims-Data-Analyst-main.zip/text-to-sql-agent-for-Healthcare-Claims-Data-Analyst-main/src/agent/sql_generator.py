"""
SQL Generator — Converts natural language questions to SQL using an LLM.

Features:
  - Structured system prompt with schema + dictionary + examples
  - Thinking traces: logs reasoning about table/column selection
  - Returns both SQL and the reasoning chain
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field

from src.agent.llm_client import call_llm

from src.config import GEMINI_MODEL, LLM_PROVIDER, OPENAI_API_KEY, OPENAI_MODEL

logger = logging.getLogger(__name__)

SYSTEM_PROMPT = """You are an expert SQL analyst for a healthcare claims database (SQLite).
Your job is to convert natural language questions into accurate, efficient SQL queries.

CRITICAL RULES:
1. Use ONLY the tables and columns described in the schema below. Never invent columns.
2. Use SQLite syntax (e.g., SUBSTR not SUBSTRING, || for concatenation, JULIANDAY for date math).
3. Always qualify column names with table aliases when joining.
4. For aggregations, include meaningful column aliases.
5. Use appropriate JOINs — do not use implicit joins.
6. When comparing dates, use ISO format strings ('YYYY-MM-DD').
7. LIMIT results to 100 rows unless the user asks for everything.
8. For percentage calculations, multiply by 100.0 (not 100) to avoid integer division.
9. Handle NULL values explicitly where relevant.
10. Only generate SELECT statements. Never generate INSERT, UPDATE, DELETE, DROP, or any DDL.

RESPONSE FORMAT:
You MUST respond with valid JSON containing exactly these keys:
{
  "thinking": "Step-by-step reasoning about which tables and columns to use and why. Include: which tables are needed, how to join them, what filters apply, what aggregations are needed.",
  "sql": "The SQL query (no markdown, no backticks, just raw SQL)",
  "explanation": "Brief plain-English explanation of what the query does"
}
"""


@dataclass
class SQLGenerationResult:
    """Result from SQL generation."""
    sql: str
    thinking: str
    explanation: str
    model: str
    prompt_tokens: int = 0
    completion_tokens: int = 0
    raw_response: str = ""
    errors: list[str] = field(default_factory=list)


def generate_sql(
    question: str,
    context: str,
    model: str | None = None,
    api_key: str | None = None,
) -> SQLGenerationResult:
    """
    Generate SQL from a natural language question.
    
    Args:
        question: User's natural language question
        context: Full context from ContextEngine.build_full_context()
        model: OpenAI model to use
        api_key: OpenAI API key
    
    Returns:
        SQLGenerationResult with SQL, thinking trace, and explanation
    """


    messages = [
        {"role": "system", "content": SYSTEM_PROMPT + "\n\n" + context},
        {"role": "user", "content": question},
    ]

    if model is None:
        model = GEMINI_MODEL if LLM_PROVIDER == "gemini" else OPENAI_MODEL

    try:
        raw = call_llm(
            messages=messages,
            json_mode=True,
            model=model,
        )
        parsed = json.loads(raw or "{}")

        return SQLGenerationResult(
            sql=parsed.get("sql", "").strip(),
            thinking=parsed.get("thinking", ""),
            explanation=parsed.get("explanation", ""),
            model=model,
            prompt_tokens=0,
            completion_tokens=0,
            raw_response=raw,
        )

    except json.JSONDecodeError as e:
        logger.error(f"Failed to parse LLM response as JSON: {e}")
        return SQLGenerationResult(
            sql="",
            thinking="",
            explanation="",
            model=model,
            raw_response=raw if 'raw' in locals() else "",
            errors=[f"JSON parse error: {e}"],
        )
    except Exception as e:
        logger.error(f"SQL generation failed: {e}")
        return SQLGenerationResult(
            sql="",
            thinking="",
            explanation="",
            model=model,
            errors=[str(e)],
        )


CORRECTION_PROMPT = """The previous SQL query produced an error. Please fix it.

Previous SQL:
{previous_sql}

Error message:
{error_message}

Please respond with corrected JSON in the same format:
{{
  "thinking": "What went wrong and how I'm fixing it",
  "sql": "The corrected SQL query",
  "explanation": "What the corrected query does"
}}
"""


def generate_corrected_sql(
    question: str,
    context: str,
    previous_sql: str,
    error_message: str,
    model: str | None = None,
    api_key: str | None = None,
) -> SQLGenerationResult:
    """
    Generate a corrected SQL query after a failed attempt.
    """


    correction_msg = CORRECTION_PROMPT.format(
        previous_sql=previous_sql,
        error_message=error_message,
    )

    messages = [
        {"role": "system", "content": SYSTEM_PROMPT + "\n\n" + context},
        {"role": "user", "content": question},
        {"role": "assistant", "content": json.dumps({"sql": previous_sql})},
        {"role": "user", "content": correction_msg},
    ]

    if model is None:
        model = GEMINI_MODEL if LLM_PROVIDER == "gemini" else OPENAI_MODEL

    try:
        raw = call_llm(
            messages=messages,
            json_mode=True,
            model=model,
        )
        parsed = json.loads(raw or "{}")

        return SQLGenerationResult(
            sql=parsed.get("sql", "").strip(),
            thinking=parsed.get("thinking", ""),
            explanation=parsed.get("explanation", ""),
            model=model,
            prompt_tokens=0,
            completion_tokens=0,
            raw_response=raw,
        )

    except Exception as e:
        logger.error(f"SQL correction failed: {e}")
        return SQLGenerationResult(
            sql="",
            thinking="",
            explanation="",
            model=model,
            errors=[str(e)],
        )
