"""
SQL Validator — Validates and self-corrects generated SQL.

Features:
  - Syntax validation via sqlite3 prepare
  - Safety checks (SELECT-only enforcement)
  - Test execution with LIMIT 1
  - Self-correction loop (up to MAX attempts)
"""

from __future__ import annotations

import logging
import re
import sqlite3
from dataclasses import dataclass, field
from pathlib import Path

from src.config import DB_PATH, MAX_SELF_CORRECTION_ATTEMPTS, SQL_RESULT_ROW_LIMIT

logger = logging.getLogger(__name__)


@dataclass
class ValidationResult:
    """Result of SQL validation."""
    is_valid: bool
    sql: str
    error_message: str = ""
    row_count: int = 0
    column_names: list[str] = field(default_factory=list)
    sample_data: list[dict] = field(default_factory=list)
    attempts: int = 1


# ── Safety Checks ────────────────────────────────────────────────────

DANGEROUS_KEYWORDS = [
    "INSERT", "UPDATE", "DELETE", "DROP", "CREATE", "ALTER",
    "TRUNCATE", "REPLACE", "ATTACH", "DETACH", "PRAGMA",
]


def _check_safety(sql: str) -> str | None:
    """
    Check if SQL is safe (SELECT-only).
    Returns error message if unsafe, None if safe.
    """
    normalized = sql.strip().upper()

    # Must start with SELECT or WITH (for CTEs)
    if not (normalized.startswith("SELECT") or normalized.startswith("WITH")):
        return f"Query must start with SELECT or WITH. Got: {normalized[:20]}..."

    # Check for dangerous keywords at statement boundaries
    for keyword in DANGEROUS_KEYWORDS:
        # Match keyword at word boundary (not inside column/table names)
        pattern = rf"\b{keyword}\b"
        if re.search(pattern, normalized) and keyword != "CREATE":
            return f"Unsafe SQL: contains {keyword} statement"
        # Special handling for CREATE — only block CREATE TABLE/INDEX, allow in subqueries
        if keyword == "CREATE" and re.search(r"\bCREATE\s+(TABLE|INDEX|VIEW|TRIGGER)", normalized):
            return f"Unsafe SQL: contains {keyword} statement"

    # Check for multiple statements (semicolon followed by non-whitespace)
    statements = [s.strip() for s in sql.split(";") if s.strip()]
    if len(statements) > 1:
        return "Multiple SQL statements detected. Only single queries are allowed."

    return None


# ── Syntax Validation ────────────────────────────────────────────────

def _validate_syntax(sql: str, db_path: Path = DB_PATH) -> str | None:
    """
    Validate SQL syntax by preparing (not executing) the statement.
    Returns error message if invalid, None if valid.
    """
    try:
        conn = sqlite3.connect(str(db_path))
        conn.execute(f"EXPLAIN QUERY PLAN {sql}")
        conn.close()
        return None
    except sqlite3.Error as e:
        return str(e)
    finally:
        try:
            conn.close()
        except Exception:
            pass


# ── Test Execution ───────────────────────────────────────────────────

def _test_execute(sql: str, db_path: Path = DB_PATH) -> ValidationResult:
    """
    Execute the SQL with a LIMIT to verify it runs successfully.
    Returns a ValidationResult with sample data.
    """
    try:
        conn = sqlite3.connect(str(db_path))
        conn.row_factory = sqlite3.Row

        # Add LIMIT if not already present
        test_sql = sql.rstrip(";")
        if "LIMIT" not in test_sql.upper():
            test_sql = f"{test_sql} LIMIT 5"

        cursor = conn.execute(test_sql)
        columns = [desc[0] for desc in cursor.description] if cursor.description else []
        rows = cursor.fetchall()
        sample = [dict(zip(columns, row)) for row in rows]

        # Get full count (without LIMIT)
        try:
            count_sql = f"SELECT COUNT(*) FROM ({sql.rstrip(';')})"
            count_cursor = conn.execute(count_sql)
            row_count = count_cursor.fetchone()[0]
        except Exception:
            row_count = len(rows)

        conn.close()

        return ValidationResult(
            is_valid=True,
            sql=sql,
            row_count=row_count,
            column_names=columns,
            sample_data=sample,
        )

    except sqlite3.Error as e:
        return ValidationResult(
            is_valid=False,
            sql=sql,
            error_message=str(e),
        )
    finally:
        try:
            conn.close()
        except Exception:
            pass


# ── Full Validation Pipeline ────────────────────────────────────────

def validate_sql(sql: str, db_path: Path = DB_PATH) -> ValidationResult:
    """
    Run full validation pipeline: safety → syntax → test execution.
    """
    if not sql or not sql.strip():
        return ValidationResult(
            is_valid=False,
            sql=sql or "",
            error_message="Empty SQL query",
        )

    # Step 1: Safety check
    safety_error = _check_safety(sql)
    if safety_error:
        return ValidationResult(is_valid=False, sql=sql, error_message=safety_error)

    # Step 2: Syntax check
    syntax_error = _validate_syntax(sql, db_path)
    if syntax_error:
        return ValidationResult(is_valid=False, sql=sql, error_message=f"Syntax error: {syntax_error}")

    # Step 3: Test execution
    return _test_execute(sql, db_path)


def execute_validated_sql(sql: str, db_path: Path = DB_PATH) -> list[dict]:
    """
    Execute a validated SQL query and return full results (up to limit).
    """
    conn = sqlite3.connect(str(db_path))
    conn.row_factory = sqlite3.Row

    # Enforce row limit
    limited_sql = sql.rstrip(";")
    if "LIMIT" not in limited_sql.upper():
        limited_sql = f"{limited_sql} LIMIT {SQL_RESULT_ROW_LIMIT}"

    try:
        cursor = conn.execute(limited_sql)
        columns = [desc[0] for desc in cursor.description] if cursor.description else []
        rows = cursor.fetchall()
        return [dict(zip(columns, row)) for row in rows]
    finally:
        conn.close()
