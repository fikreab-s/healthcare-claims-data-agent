"""
Natural Language Responder — Converts SQL results into human-readable answers.

Uses the LLM to generate a natural language summary of the query results,
including key findings and relevant context.
"""

from __future__ import annotations

import json
import logging

from src.agent.llm_client import call_llm

from src.config import GEMINI_MODEL, LLM_PROVIDER, OPENAI_API_KEY, OPENAI_MODEL

logger = logging.getLogger(__name__)

NL_SYSTEM_PROMPT = """You are a healthcare data analyst assistant.
Given a user's question, the SQL query that was executed, and the results, 
provide a clear, concise natural language answer.

RULES:
1. Start with a direct answer to the question.
2. Include specific numbers and statistics from the results.
3. Format large numbers with commas (e.g., 1,234,567).
4. Round decimal values to 2 places for readability.
5. If the results show a trend, describe it.
6. If the results are empty, explain what that means.
7. Keep the response concise — 2-4 sentences for simple queries, up to a paragraph for complex ones.
8. Use bullet points for lists of more than 3 items.

RESPONSE FORMAT:
{
  "answer": "The natural language answer to display to the user",
  "key_insights": ["insight 1", "insight 2"],
  "suggested_followups": ["follow-up question 1", "follow-up question 2"]
}
"""


def generate_nl_response(
    question: str,
    sql: str,
    results: list[dict],
    model: str | None = None,
    api_key: str | None = None,
) -> dict:
    """
    Generate a natural language response from SQL results.
    
    Returns dict with keys: answer, key_insights, suggested_followups
    """
    # Truncate results for the prompt (show up to 50 rows)
    display_results = results[:50]
    results_str = json.dumps(display_results, indent=2, default=str)
    total_rows = len(results)

    if model is None:
        model = GEMINI_MODEL if LLM_PROVIDER == "gemini" else OPENAI_MODEL

    user_msg = f"""Question: {question}

SQL Executed:
```sql
{sql}
```

Results ({total_rows} total rows, showing first {len(display_results)}):
{results_str}"""



    try:
        raw = call_llm(
            messages=[
                {"role": "system", "content": NL_SYSTEM_PROMPT},
                {"role": "user", "content": user_msg},
            ],
            json_mode=True,
            model=model,
            temperature=0.3,
        )
        parsed = json.loads(raw or "{}")

        return {
            "answer": parsed.get("answer", "I wasn't able to generate a summary."),
            "key_insights": parsed.get("key_insights", []),
            "suggested_followups": parsed.get("suggested_followups", []),
        }

    except Exception as e:
        logger.error(f"NL response generation failed: {e}")
        # Fallback: generate a basic response
        if results:
            return {
                "answer": f"The query returned {total_rows} row(s). Here are the results.",
                "key_insights": [],
                "suggested_followups": [],
            }
        return {
            "answer": "The query returned no results.",
            "key_insights": [],
            "suggested_followups": [],
        }
