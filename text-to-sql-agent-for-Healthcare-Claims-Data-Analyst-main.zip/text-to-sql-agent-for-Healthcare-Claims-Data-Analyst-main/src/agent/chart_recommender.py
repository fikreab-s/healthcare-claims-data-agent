"""
Chart Recommender — Auto-detects the best visualization for SQL results.

Analyzes the shape and content of query results to recommend
an appropriate chart type and Plotly configuration.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field

import pandas as pd

logger = logging.getLogger(__name__)


@dataclass
class ChartRecommendation:
    """Recommended chart configuration."""
    chart_type: str  # "bar", "line", "pie", "table", "scatter", "hbar"
    title: str
    x_column: str = ""
    y_column: str = ""
    color_column: str = ""
    reason: str = ""
    is_chartable: bool = True


def recommend_chart(results: list[dict], question: str = "") -> ChartRecommendation:
    """
    Analyze query results and recommend the best chart type.
    
    Heuristics:
      - 1 row → table only
      - Time-like x + numeric y → line chart
      - Categorical x + numeric y → bar chart
      - 2-5 categories with a single numeric value → pie chart
      - 2 numeric columns → scatter plot
    """
    if not results:
        return ChartRecommendation(
            chart_type="table", title="No Data", is_chartable=False,
            reason="No results to visualize"
        )

    df = pd.DataFrame(results)
    n_rows = len(df)
    n_cols = len(df.columns)

    if n_rows == 1 or n_cols == 1:
        return ChartRecommendation(
            chart_type="table", title="Query Results", is_chartable=False,
            reason="Single row/column — best displayed as table"
        )

    # Classify columns
    numeric_cols = df.select_dtypes(include=["number"]).columns.tolist()
    non_numeric_cols = [c for c in df.columns if c not in numeric_cols]

    # Detect time-like columns
    time_cols = []
    for col in non_numeric_cols:
        sample = str(df[col].iloc[0]) if not df[col].empty else ""
        if any(kw in col.lower() for kw in ["date", "month", "year", "quarter", "week", "period"]):
            time_cols.append(col)
        elif len(sample) >= 7 and sample[:4].isdigit() and sample[4] in "-/":
            time_cols.append(col)

    categorical_cols = [c for c in non_numeric_cols if c not in time_cols]
    question_lower = question.lower()

    # ── Decision Logic ───────────────────────────────────────────

    # Time series → Line chart
    if time_cols and numeric_cols:
        return ChartRecommendation(
            chart_type="line",
            title=_infer_title(question, "Trend"),
            x_column=time_cols[0],
            y_column=numeric_cols[0],
            reason=f"Time-series data detected ({time_cols[0]})"
        )

    # Pie chart: small number of categories with a single metric
    if (
        categorical_cols
        and numeric_cols
        and 2 <= n_rows <= 6
        and any(kw in question_lower for kw in ["breakdown", "distribution", "proportion", "share", "percentage", "by status"])
    ):
        return ChartRecommendation(
            chart_type="pie",
            title=_infer_title(question, "Distribution"),
            x_column=categorical_cols[0],
            y_column=numeric_cols[0],
            reason=f"Small categorical distribution ({n_rows} categories)"
        )

    # Bar chart: categorical x + numeric y
    if categorical_cols and numeric_cols:
        # Horizontal bar for many categories
        if n_rows > 10:
            return ChartRecommendation(
                chart_type="hbar",
                title=_infer_title(question, "Comparison"),
                x_column=numeric_cols[0],
                y_column=categorical_cols[0],
                reason=f"Many categories ({n_rows}) — horizontal bar for readability"
            )
        return ChartRecommendation(
            chart_type="bar",
            title=_infer_title(question, "Comparison"),
            x_column=categorical_cols[0],
            y_column=numeric_cols[0],
            reason=f"Categorical comparison ({categorical_cols[0]} vs {numeric_cols[0]})"
        )

    # Scatter: two numeric columns, no useful categorical
    if len(numeric_cols) >= 2 and not categorical_cols:
        return ChartRecommendation(
            chart_type="scatter",
            title=_infer_title(question, "Relationship"),
            x_column=numeric_cols[0],
            y_column=numeric_cols[1],
            reason="Two numeric dimensions — scatter plot"
        )

    # Default: table
    return ChartRecommendation(
        chart_type="table",
        title="Query Results",
        is_chartable=False,
        reason="No suitable chart type detected"
    )


def _infer_title(question: str, fallback: str) -> str:
    """Generate a chart title from the question."""
    if question:
        # Capitalize first letter, remove trailing punctuation
        title = question.strip().rstrip("?. !")
        if len(title) > 60:
            title = title[:57] + "..."
        return title
    return fallback
