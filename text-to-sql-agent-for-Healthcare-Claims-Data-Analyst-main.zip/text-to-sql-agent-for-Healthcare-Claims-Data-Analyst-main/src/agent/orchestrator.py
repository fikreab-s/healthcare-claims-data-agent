"""
Orchestrator — Main agent pipeline that ties everything together.

Pipeline:  user_question → context_engine → sql_generator → sql_validator
           → execute → nl_responder → chart_recommender

Includes self-correction loop and full tracing.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from pathlib import Path

from src.agent.chart_recommender import ChartRecommendation, recommend_chart
from src.agent.context_engine import ContextEngine
from src.agent.nl_responder import generate_nl_response
from src.agent.sql_generator import SQLGenerationResult, generate_corrected_sql, generate_sql
from src.agent.sql_validator import ValidationResult, execute_validated_sql, validate_sql
from src.config import DB_PATH, MAX_SELF_CORRECTION_ATTEMPTS
from src.tracing.otel_setup import get_tracer

logger = logging.getLogger(__name__)


@dataclass
class AgentResponse:
    """Complete response from the Text-to-SQL agent."""
    # Input
    question: str

    # SQL Generation
    sql: str = ""
    thinking: str = ""
    sql_explanation: str = ""

    # Validation
    is_valid: bool = False
    validation_error: str = ""
    correction_attempts: int = 0

    # Results
    results: list[dict] = field(default_factory=list)
    row_count: int = 0
    column_names: list[str] = field(default_factory=list)

    # Natural Language
    nl_answer: str = ""
    key_insights: list[str] = field(default_factory=list)
    suggested_followups: list[str] = field(default_factory=list)

    # Chart
    chart: ChartRecommendation | None = None

    # Metadata
    total_time_ms: float = 0
    generation_time_ms: float = 0
    model: str = ""
    prompt_tokens: int = 0
    completion_tokens: int = 0
    errors: list[str] = field(default_factory=list)

    @property
    def success(self) -> bool:
        return self.is_valid and bool(self.sql)


class TextToSQLAgent:
    """Main agent orchestrator."""

    def __init__(self, db_path: Path = DB_PATH):
        self.db_path = db_path
        self.context_engine = ContextEngine(db_path=db_path)

    def query(self, question: str) -> AgentResponse:
        """
        Process a natural language question end-to-end.
        
        Steps:
          1. Build context (schema + dictionary + examples + history)
          2. Generate SQL with thinking traces
          3. Validate SQL (safety + syntax + test execution)
          4. Self-correct if validation fails (up to N attempts)
          5. Execute validated SQL
          6. Generate natural language response
          7. Recommend chart visualization
        """
        start_time = time.time()
        response = AgentResponse(question=question)
        tracer = get_tracer()

        # Start trace span
        span = None
        if tracer:
            span = tracer.start_span("agent.query")
            span.set_attribute("question", question)

        try:
            # ── Step 1: Build Context ────────────────────────────────
            context = self.context_engine.build_full_context()

            # ── Step 2: Generate SQL ─────────────────────────────────
            gen_start = time.time()
            gen_result = generate_sql(question, context)
            response.generation_time_ms = (time.time() - gen_start) * 1000

            response.sql = gen_result.sql
            response.thinking = gen_result.thinking
            response.sql_explanation = gen_result.explanation
            response.model = gen_result.model
            response.prompt_tokens = gen_result.prompt_tokens
            response.completion_tokens = gen_result.completion_tokens

            if gen_result.errors:
                response.errors.extend(gen_result.errors)
                return response

            # ── Step 3: Validate SQL ─────────────────────────────────
            validation = validate_sql(gen_result.sql, self.db_path)

            # ── Step 4: Self-Correction Loop ─────────────────────────
            attempt = 0
            while not validation.is_valid and attempt < MAX_SELF_CORRECTION_ATTEMPTS:
                attempt += 1
                logger.info(
                    f"Self-correction attempt {attempt}: {validation.error_message}"
                )

                corrected = generate_corrected_sql(
                    question=question,
                    context=context,
                    previous_sql=response.sql,
                    error_message=validation.error_message,
                )

                response.sql = corrected.sql
                response.thinking += f"\n\n--- Correction Attempt {attempt} ---\n{corrected.thinking}"
                response.prompt_tokens += corrected.prompt_tokens
                response.completion_tokens += corrected.completion_tokens

                if corrected.errors:
                    response.errors.extend(corrected.errors)
                    break

                validation = validate_sql(corrected.sql, self.db_path)

            response.correction_attempts = attempt
            response.is_valid = validation.is_valid
            response.validation_error = validation.error_message
            response.column_names = validation.column_names

            if not validation.is_valid:
                response.errors.append(f"Validation failed after {attempt} corrections: {validation.error_message}")
                return response

            # ── Step 5: Execute Full Query ───────────────────────────
            response.results = execute_validated_sql(response.sql, self.db_path)
            response.row_count = len(response.results)

            # ── Step 6: Generate NL Response ─────────────────────────
            nl_result = generate_nl_response(
                question=question,
                sql=response.sql,
                results=response.results,
            )
            response.nl_answer = nl_result["answer"]
            response.key_insights = nl_result["key_insights"]
            response.suggested_followups = nl_result["suggested_followups"]

            # ── Step 7: Recommend Chart ──────────────────────────────
            response.chart = recommend_chart(response.results, question)

            # Update conversation history
            self.context_engine.add_to_history("user", question)
            self.context_engine.add_to_history(
                "assistant",
                f"SQL: {response.sql}\nAnswer: {response.nl_answer}"
            )

        except Exception as e:
            logger.exception(f"Agent query failed: {e}")
            response.errors.append(str(e))

        finally:
            response.total_time_ms = (time.time() - start_time) * 1000
            if span:
                span.set_attribute("sql", response.sql)
                span.set_attribute("success", response.success)
                span.set_attribute("total_time_ms", response.total_time_ms)
                span.set_attribute("correction_attempts", response.correction_attempts)
                span.end()

        return response
