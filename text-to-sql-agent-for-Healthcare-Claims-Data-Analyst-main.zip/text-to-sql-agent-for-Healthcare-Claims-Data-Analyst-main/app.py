"""
Text-to-SQL Agent — Streamlit Application

A premium healthcare claims data explorer powered by AI.
"""

import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import time
import logging

logging.basicConfig(level=logging.INFO)

# ── Page Config ──────────────────────────────────────────────────────
st.set_page_config(
    page_title="Healthcare Claims AI Analyst",
    page_icon="🏥",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Custom CSS ───────────────────────────────────────────────────────
st.markdown("""
<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');

    /* Global */
    .stApp {
        font-family: 'Inter', sans-serif;
    }

    /* Header */
    .main-header {
        background: linear-gradient(135deg, #0f172a 0%, #1e293b 50%, #0f766e 100%);
        padding: 1.5rem 2rem;
        border-radius: 16px;
        margin-bottom: 1.5rem;
        color: white;
    }
    .main-header h1 {
        margin: 0;
        font-size: 1.8rem;
        font-weight: 700;
        letter-spacing: -0.02em;
    }
    .main-header p {
        margin: 0.3rem 0 0 0;
        opacity: 0.8;
        font-size: 0.95rem;
    }

    /* Cards */
    .metric-card {
        background: linear-gradient(135deg, #f0fdfa, #f0f9ff);
        border: 1px solid #e0f2fe;
        border-radius: 12px;
        padding: 1rem 1.2rem;
        text-align: center;
    }
    .metric-card h3 {
        font-size: 0.75rem;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        color: #64748b;
        margin: 0;
    }
    .metric-card p {
        font-size: 1.5rem;
        font-weight: 700;
        color: #0f172a;
        margin: 0.3rem 0 0 0;
    }

    /* SQL Block */
    .sql-block {
        background: #1e293b;
        border-radius: 12px;
        padding: 1rem 1.5rem;
        color: #e2e8f0;
        font-family: 'JetBrains Mono', 'Fira Code', monospace;
        font-size: 0.85rem;
        line-height: 1.6;
        overflow-x: auto;
    }

    /* Thinking trace */
    .thinking-trace {
        background: #fefce8;
        border-left: 4px solid #eab308;
        border-radius: 0 8px 8px 0;
        padding: 0.8rem 1rem;
        font-size: 0.85rem;
        color: #713f12;
        line-height: 1.5;
    }

    /* Answer card */
    .answer-card {
        background: linear-gradient(135deg, #f0fdfa, #ecfdf5);
        border: 1px solid #a7f3d0;
        border-radius: 12px;
        padding: 1.2rem 1.5rem;
        font-size: 1rem;
        line-height: 1.6;
        color: #064e3b;
    }

    /* Insight chips */
    .insight-chip {
        display: inline-block;
        background: #dbeafe;
        color: #1e40af;
        padding: 0.3rem 0.8rem;
        border-radius: 20px;
        font-size: 0.8rem;
        margin: 0.2rem;
    }

    /* Sidebar */
    section[data-testid="stSidebar"] {
        background: linear-gradient(180deg, #0f172a, #1e293b);
    }
    section[data-testid="stSidebar"] .stMarkdown {
        color: #e2e8f0;
    }

    /* Hide streamlit branding */
    #MainMenu {visibility: hidden;}
    footer {visibility: hidden;}
</style>
""", unsafe_allow_html=True)


# ── Initialize Session State ────────────────────────────────────────
if "agent" not in st.session_state:
    from src.agent.orchestrator import TextToSQLAgent
    st.session_state.agent = TextToSQLAgent()

if "history" not in st.session_state:
    st.session_state.history = []

if "phoenix_launched" not in st.session_state:
    try:
        from src.tracing.otel_setup import init_tracing
        init_tracing(launch_phoenix=True)
        st.session_state.phoenix_launched = True
    except Exception:
        st.session_state.phoenix_launched = False


# ── Header ──────────────────────────────────────────────────────────
st.markdown("""
<div class="main-header">
    <h1>🏥 Healthcare Claims AI Analyst</h1>
    <p>Ask questions about healthcare claims data in plain English — powered by GPT-4o + SQLite</p>
</div>
""", unsafe_allow_html=True)


# ── Sidebar ─────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("### ⚙️ Settings")

    show_sql = st.toggle("Show Generated SQL", value=True)
    show_thinking = st.toggle("Show Thinking Traces", value=True)
    show_chart = st.toggle("Show Auto Charts", value=True)

    st.markdown("---")

    st.markdown("### 📊 Database Info")
    try:
        from src.db.connection import get_table_names, execute_query
        tables = get_table_names()
        for table in tables:
            count = execute_query(f"SELECT COUNT(*) as n FROM {table}")[0]["n"]
            st.markdown(f"**`{table}`** — {count:,} rows")
    except Exception:
        st.markdown("_Database not loaded_")

    st.markdown("---")

    st.markdown("### 🔍 Example Questions")
    examples = [
        "What are the top 5 providers by total billed amount?",
        "Show claim count by status",
        "Monthly trend of total paid amounts",
        "Which specialties have the highest denial rates?",
        "Compare in-network vs out-of-network costs",
        "Top 10 most common diagnoses",
        "Average member out-of-pocket by plan type",
        "How many ER visits per state?",
    ]
    for ex in examples:
        if st.button(ex, key=f"ex_{hash(ex)}", use_container_width=True):
            st.session_state.current_question = ex

    st.markdown("---")

    if st.session_state.phoenix_launched:
        st.markdown("### 🔭 Tracing")
        st.markdown("[Open Phoenix UI →](http://localhost:6006)")
    
    if st.button("🗑️ Clear History", use_container_width=True):
        st.session_state.history = []
        st.session_state.agent.context_engine.clear_history()
        st.rerun()


# ── Main Query Input ────────────────────────────────────────────────
question = st.chat_input("Ask a question about healthcare claims data...")

# Handle example button clicks
if "current_question" in st.session_state:
    question = st.session_state.current_question
    del st.session_state.current_question

# ── Display History ─────────────────────────────────────────────────
for entry in st.session_state.history:
    with st.chat_message("user"):
        st.write(entry["question"])

    with st.chat_message("assistant", avatar="🏥"):
        _render_response(entry["response"]) if callable(globals().get('_render_response')) else None


# ── Process New Query ───────────────────────────────────────────────
def render_response(resp):
    """Render an AgentResponse in the chat."""
    if not resp.success:
        st.error(f"❌ Query failed: {'; '.join(resp.errors) or resp.validation_error}")
        if resp.sql and show_sql:
            st.markdown("**Attempted SQL:**")
            st.code(resp.sql, language="sql")
        return

    # Answer
    st.markdown(f'<div class="answer-card">{resp.nl_answer}</div>', unsafe_allow_html=True)

    # Key insights
    if resp.key_insights:
        st.markdown("**Key Insights:**")
        for insight in resp.key_insights:
            st.markdown(f'<span class="insight-chip">💡 {insight}</span>', unsafe_allow_html=True)

    # SQL
    if show_sql:
        with st.expander("🔍 Generated SQL", expanded=False):
            st.code(resp.sql, language="sql")
            st.caption(f"_{resp.sql_explanation}_")

    # Thinking trace
    if show_thinking and resp.thinking:
        with st.expander("🧠 Thinking Trace", expanded=False):
            st.markdown(f'<div class="thinking-trace">{resp.thinking}</div>', unsafe_allow_html=True)

    # Data table
    if resp.results:
        df = pd.DataFrame(resp.results)
        with st.expander(f"📋 Data Table ({resp.row_count} rows)", expanded=True):
            st.dataframe(df, use_container_width=True, height=min(400, 35 * len(df) + 38))

    # Chart
    if show_chart and resp.chart and resp.chart.is_chartable and resp.results:
        df = pd.DataFrame(resp.results)
        with st.expander("📊 Visualization", expanded=True):
            try:
                fig = _build_chart(df, resp.chart)
                if fig:
                    st.plotly_chart(fig, use_container_width=True)
            except Exception as e:
                st.caption(f"_Could not generate chart: {e}_")

    # Suggested follow-ups
    if resp.suggested_followups:
        st.markdown("**Suggested Follow-ups:**")
        cols = st.columns(min(len(resp.suggested_followups), 3))
        for i, q in enumerate(resp.suggested_followups[:3]):
            with cols[i]:
                if st.button(f"💬 {q}", key=f"fu_{hash(q)}_{time.time()}", use_container_width=True):
                    st.session_state.current_question = q
                    st.rerun()

    # Metadata
    with st.expander("⚡ Performance", expanded=False):
        mcols = st.columns(4)
        mcols[0].metric("Total Time", f"{resp.total_time_ms:.0f} ms")
        mcols[1].metric("Generation", f"{resp.generation_time_ms:.0f} ms")
        mcols[2].metric("Tokens (in)", f"{resp.prompt_tokens:,}")
        mcols[3].metric("Tokens (out)", f"{resp.completion_tokens:,}")
        if resp.correction_attempts > 0:
            st.warning(f"⚠️ Self-corrected {resp.correction_attempts} time(s)")


def _build_chart(df: pd.DataFrame, chart: 'ChartRecommendation') -> go.Figure | None:
    """Build a Plotly chart from recommendation."""
    color_scheme = px.colors.qualitative.Set2

    if chart.chart_type == "bar":
        fig = px.bar(
            df, x=chart.x_column, y=chart.y_column,
            title=chart.title,
            color_discrete_sequence=["#0d9488"],
        )
    elif chart.chart_type == "hbar":
        fig = px.bar(
            df, x=chart.x_column, y=chart.y_column,
            title=chart.title, orientation="h",
            color_discrete_sequence=["#0d9488"],
        )
    elif chart.chart_type == "line":
        fig = px.line(
            df, x=chart.x_column, y=chart.y_column,
            title=chart.title, markers=True,
            color_discrete_sequence=["#0d9488"],
        )
    elif chart.chart_type == "pie":
        fig = px.pie(
            df, names=chart.x_column, values=chart.y_column,
            title=chart.title,
            color_discrete_sequence=color_scheme,
        )
    elif chart.chart_type == "scatter":
        fig = px.scatter(
            df, x=chart.x_column, y=chart.y_column,
            title=chart.title,
            color_discrete_sequence=["#0d9488"],
        )
    else:
        return None

    fig.update_layout(
        template="plotly_white",
        font=dict(family="Inter, sans-serif"),
        title_font_size=16,
        margin=dict(t=50, b=40, l=40, r=20),
    )
    return fig


# ── Process query ───────────────────────────────────────────────────
if question:
    with st.chat_message("user"):
        st.write(question)

    with st.chat_message("assistant", avatar="🏥"):
        with st.spinner("🔍 Analyzing your question..."):
            resp = st.session_state.agent.query(question)
        render_response(resp)

    # Save to history
    st.session_state.history.append({
        "question": question,
        "response": resp,
    })


# ── Footer ──────────────────────────────────────────────────────────
if not question and not st.session_state.history:
    st.markdown("---")
    st.markdown("""
    <div style="text-align: center; color: #94a3b8; padding: 2rem;">
        <p style="font-size: 2rem; margin-bottom: 0.5rem;">🏥 💬 📊</p>
        <p style="font-size: 1.1rem; font-weight: 500;">Ask any question about healthcare claims data</p>
        <p style="font-size: 0.9rem;">Try an example from the sidebar, or type your own question below</p>
    </div>
    """, unsafe_allow_html=True)
