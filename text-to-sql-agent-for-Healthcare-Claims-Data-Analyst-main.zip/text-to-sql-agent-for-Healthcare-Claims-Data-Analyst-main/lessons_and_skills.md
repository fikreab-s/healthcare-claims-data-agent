# Lessons & Skills for Building Agentic Text-to-SQL Systems

> Extracted from provided resources on compounding engineering, OpenAI's internal data agent, and community best practices.

---

## 1. Compounding Engineering Pattern

**Core Principle**: Every feature should make the next feature *easier* to build (not harder).

### The Loop: Plan → Delegate → Assess → Codify
1. **Plan** — Define the task in detail before delegating to AI
2. **Delegate** — Let the agent execute the implementation
3. **Assess** — Verify correctness, catch edge cases
4. **Codify** — Embed lessons back into the system (prompts, workflows, tests)

### Codification Targets
| Artifact | Purpose |
|----------|---------|
| System Prompts / `.md` files | Global coding standards, domain context |
| Slash Commands / Workflows | Repeatable processes (e.g., `/test`, `/deploy`) |
| Subagents | Specialized validators (security, SQL lint, style) |
| Hooks | Automated checks to prevent regressions |
| Tests | Encode requirements as executable assertions |

### Key Quotes
- *"In compounding engineering, your goal is to make the next feature easier to build from the feature you just added."* — Dan Shipper
- *"I can hop into one of our code bases and start being productive even though I don't know anything about how the code works because we have this built-up memory system."*

---

## 2. OpenAI's Text-to-SQL Agent Architecture

**Core Insight**: Context is everything. You cannot just point an LLM at a schema and expect reliable answers.

### Six Layers of Context
1. **Table Usage** — Schema metadata (columns, types, lineage), historical query patterns
2. **Human Annotations** — Domain expert descriptions of business logic, metric definitions
3. **Code-Level Semantics** — How tables are generated/transformed (ETL lineage)
4. **Documentation** — Institutional knowledge bases, data dictionaries
5. **Conversational Memory** — Structured, editable memory of past interactions within a session
6. **Runtime Inspection** — Live queries to validate schemas and understand data in real-time

### Self-Correction Loop
The agent doesn't just generate SQL — it **validates results**:
- Execute the query
- Check for unexpected outcomes (zero rows, type mismatches)
- Debug and correct autonomously
- Re-execute until results are reasonable

### Golden Query Evaluation
- Curate a set of question → SQL → expected-answer triples
- Compare *data results* (not SQL strings) to handle syntactic variation
- Continuously expand the golden set from successful user interactions

### Security: Pass-Through Permissions
- Non-deterministic SQL generation paired with **deterministic access controls**
- Users can only query data they're already authorized to access
- Security cannot be probabilistic

### Transparency & Interpretability
- Expose reasoning traces alongside results
- Link to raw query results so users can verify
- Show which tables and columns were used and why

---

## 3. Agent Development Best Practices

### File Stack for Agent-Driven Development
| File | Purpose |
|------|---------|
| `Prompt.md` | Spec + deliverables for the AI |
| `Plans.md` | Milestones + validation criteria |
| `Architecture.md` | Principles + constraints |
| `Implement.md` | Execution instructions referencing the plan |
| `Documentation.md` | Status + decisions as shipped |
| `PROGRESS.md` | Living status tracker — what's done, what's next |
| `README.md` | Updated frequently for onboarding and self-teaching |

### Thinking Traces
- Log the agent's reasoning at each decision point
- Include: which tables were considered, why columns were selected, disambiguation logic
- Use structured spans (OpenTelemetry) for machine-readable traces

### Context Graph
- Model relationships between: tables ↔ columns ↔ business terms ↔ calculations
- Enable the agent to navigate from a user's business language to the correct schema elements
- Maintain organizational context (team definitions, metric ownership)

### Hierarchical Mixture of Recursive, Self-Improving Agents
- **Orchestrator Agent**: Routes queries, manages workflow
- **SQL Generator Agent**: Produces candidate queries
- **Validator Agent**: Reviews SQL for correctness, safety, performance
- **Explainer Agent**: Converts results to natural language
- **Learner Agent**: Observes all interactions, extracts patterns, updates knowledge base
- Each agent specializes → they "argue" and surface better answers

### Self-Improvement / Learner Module
- Capture every interaction: query, generated SQL, result, user feedback
- Periodically analyze failures → identify systematic gaps (missing schema context, ambiguous terms)
- Auto-generate golden queries from validated user interactions
- Update data dictionary and annotations automatically
- Maintain a **lessons log** that grows over time

---

## 4. Key Lessons for Our Implementation

### ✅ Do
- **Layer context deeply**: Schema alone is insufficient — add annotations, dictionary, lineage
- **Use golden queries as evals**: Build from day one, expand continuously
- **Show your work**: Display SQL, reasoning, and traces — transparency builds trust
- **Codify every learning**: Each bug fix, user correction, or edge case → update the knowledge base
- **Self-correct before responding**: Validate SQL results, retry on errors
- **Track everything with OpenTelemetry**: Spans for each agent step, latency, token usage
- **Maintain living documentation**: `PROGRESS.md`, `README.md`, `learner_log.md` updated after every session

### ❌ Don't
- Don't just generate SQL without validating results
- Don't rely on schema alone — business context is essential
- Don't treat context as a one-time setup — it's ongoing
- Don't skip evals — golden queries are non-negotiable
- Don't ignore security — even for internal tools
- Don't accumulate tech debt — refactor into the compounding loop

---

## 5. Skills to Implement

1. **Schema Introspection** — Dynamically read SQLite schema and infer relationships
2. **Prompt Engineering** — Multi-shot prompting with few-shot examples from golden queries
3. **SQL Validation** — Parse and validate generated SQL before execution
4. **Result Interpretation** — Convert tabular data into natural language summaries
5. **Chart Generation** — Auto-detect appropriate visualization (bar, line, pie) from result shape
6. **Trace Instrumentation** — OpenTelemetry spans with Phoenix for observability
7. **Feedback Loop** — Capture user corrections and feed back into context layers
8. **Memory Management** — Session-level conversation memory for follow-up questions
